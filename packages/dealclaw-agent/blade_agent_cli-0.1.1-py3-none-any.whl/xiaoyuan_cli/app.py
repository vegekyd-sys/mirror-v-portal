"""Typer 入口：按 catalog 注册子命令。"""

from __future__ import annotations

import inspect
from pathlib import Path
from typing import Annotated, Any, Optional

import typer

from xiaoyuan_cli.catalog import COMMANDS
from xiaoyuan_cli.client import AdapterError, auth_mode, post_json, post_multipart_file
from xiaoyuan_cli.config import Settings, get_settings
from xiaoyuan_cli.emit import emit, emit_error
from xiaoyuan_cli.spec import Arg, Command

app = typer.Typer(
    name="xiaoyuan",
    help="小元 CLI：直连 blade-agent-adapter /agent/**（不走 MCP 协议）",
    no_args_is_help=True,
    pretty_exceptions_enable=False,
)


def _parse_csv_str(raw: str | None) -> list[str]:
    if raw is None or str(raw).strip() == "":
        return []
    return [p.strip().strip('"').strip("'") for p in str(raw).split(",") if p.strip()]


def _parse_csv_int(raw: str | None) -> list[int]:
    out: list[int] = []
    for token in _parse_csv_str(raw):
        out.append(int(token))
    return out


def _parse_apollo_contacts(raw: Any) -> list[dict[str, str]]:
    if raw is None or str(raw).strip() == "":
        return []
    out: list[dict[str, str]] = []
    for entry in str(raw).split(";"):
        entry = entry.strip()
        if not entry:
            continue
        parts = [p.strip() for p in entry.split(":")]
        if len(parts) < 3 or not all(parts[:3]):
            continue
        item: dict[str, str] = {
            "firstName": parts[0],
            "lastName": parts[1],
            "domain": parts[2],
        }
        if len(parts) > 3 and parts[3]:
            item["organizationName"] = parts[3]
        out.append(item)
    return out


def _cli_name(arg: Arg) -> str:
    return arg.name.replace("-", "_")


def _option_for(arg: Arg) -> Any:
    flag = f"--{arg.name}"
    help_text = arg.help or arg.json_key
    if arg.kind in ("csv_str", "csv_int", "str", "file", "apollo_contacts"):
        default = ... if arg.required else (arg.default if arg.default is not None else None)
        return typer.Option(default, flag, help=help_text)
    if arg.kind == "int":
        default = ... if arg.required else arg.default
        return typer.Option(default, flag, help=help_text)
    if arg.kind == "bool":
        return typer.Option(bool(arg.default), flag, help=help_text)
    raise ValueError(f"unknown kind {arg.kind}")


def _annotation_for(arg: Arg) -> Any:
    if arg.kind == "int":
        return Optional[int] if not arg.required else int
    if arg.kind == "bool":
        return bool
    return Optional[str] if not arg.required else str


def _value_for(arg: Arg, raw: Any) -> Any:
    if arg.kind == "csv_str":
        return _parse_csv_str(None if raw is None else str(raw))
    if arg.kind == "csv_int":
        return _parse_csv_int(None if raw is None else str(raw))
    if arg.kind == "bool":
        return bool(raw)
    if arg.kind == "int":
        return raw
    if raw is None:
        return None
    s = str(raw).strip()
    return s if s else None


def _omit(arg: Arg, value: Any) -> bool:
    if value is None:
        return True
    if value == "":
        return True
    if value == []:
        return True
    if arg.kind == "bool" and value is False and arg.json_key in (
        "requireEmailBusiness",
        "decisionMaker",
        "isPreviousOnExhibitionBuyer",
        "isThisExhibitionPreBuyer",
        "isKp",
    ):
        return True
    return False


def build_body(cmd: Command, kwargs: dict[str, Any]) -> dict[str, Any]:
    body: dict[str, Any] = {}
    for arg in cmd.args:
        if arg.kind in ("file", "apollo_contacts"):
            continue
        raw = kwargs.get(_cli_name(arg))
        value = _value_for(arg, raw)
        if _omit(arg, value):
            continue
        body[arg.json_key] = value
    if cmd.path == "/agent/apollo/revealEmails.json":
        body["contacts"] = _parse_apollo_contacts(kwargs.get("contacts"))
    if cmd.path == "/agent/colleague/searchList.json":
        body.setdefault("dataSource", 1)
        province = body.pop("province", None)
        city = body.pop("city", None)
        district = body.pop("district", None)
        if province or city or district:
            body["counties"] = [
                {
                    k: v
                    for k, v in (("province", province), ("city", city), ("district", district))
                    if v
                }
            ]
    if cmd.path == "/agent/company/getInvitationByPage.json":
        body = {"data": body, "appVersion": "WEB"}
    return body


def _run_ping(settings: Settings, message: str) -> None:
    emit(
        {
            "ok": True,
            "echo": message,
            "adapterBaseUrl": settings.adapter_base_url,
            "authMode": auth_mode(settings),
            "apiKeyConfigured": bool(settings.api_key.strip()),
            "feishuConfigured": bool((settings.open_id or "").strip() and (settings.supplier_id or "").strip()),
        }
    )


def _run_command(cmd: Command, settings: Settings, kwargs: dict[str, Any]) -> None:
    if cmd.special == "ping":
        _run_ping(settings, str(kwargs.get("message") or "pong"))
        return
    body = build_body(cmd, kwargs)
    if cmd.validate:
        err = cmd.validate(body)
        if err:
            emit_error(err)
            raise typer.Exit(2)
    timeout = max(settings.adapter_timeout, cmd.timeout)
    try:
        if cmd.multipart_field:
            file_arg = next(a for a in cmd.args if a.kind == "file")
            file_path = kwargs.get(_cli_name(file_arg))
            if not file_path:
                emit_error("file 不能为空")
                raise typer.Exit(2)
            p = Path(str(file_path)).expanduser()
            if not p.is_file():
                emit_error(f"文件不存在: {p}")
                raise typer.Exit(2)
            resp = post_multipart_file(
                settings,
                cmd.path or "",
                str(p),
                field_name=cmd.multipart_field,
                timeout=timeout,
            )
            emit(
                {
                    "path": cmd.path,
                    "request": {"file": str(p), "filename": p.name},
                    "response": resp,
                }
            )
            return
        resp = post_json(settings, cmd.path or "", body, timeout=timeout)
    except AdapterError as e:
        emit_error(str(e))
        raise typer.Exit(1) from e
    emit({"path": cmd.path, "request": body, "response": resp})


def _filled(value: Any) -> bool:
    return value is not None and str(value).strip() != ""


def _merge_settings(ctx: typer.Context) -> Settings:
    base = get_settings()
    over = ctx.obj or {}
    return Settings(
        adapter_base_url=over.get("base_url") if _filled(over.get("base_url")) else base.adapter_base_url,
        open_id=over.get("open_id") if _filled(over.get("open_id")) else base.open_id,
        supplier_id=over.get("supplier_id") if _filled(over.get("supplier_id")) else base.supplier_id,
        api_key=over.get("api_key") if _filled(over.get("api_key")) else base.api_key,
        adapter_timeout=over.get("timeout") if over.get("timeout") is not None else base.adapter_timeout,
    )


def _register(cmd: Command, parent: typer.Typer) -> None:
    params: list[inspect.Parameter] = [
        inspect.Parameter(
            "ctx",
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            annotation=typer.Context,
        )
    ]
    if cmd.special == "ping":
        params.append(
            inspect.Parameter(
                "message",
                inspect.Parameter.KEYWORD_ONLY,
                default=typer.Option("pong", "--message", help="回显内容"),
                annotation=str,
            )
        )
    else:
        for arg in cmd.args:
            params.append(
                inspect.Parameter(
                    _cli_name(arg),
                    inspect.Parameter.KEYWORD_ONLY,
                    default=_option_for(arg),
                    annotation=_annotation_for(arg),
                )
            )

    def handler(ctx: typer.Context, **kwargs: Any) -> None:
        settings = _merge_settings(ctx)
        _run_command(cmd, settings, kwargs)

    handler.__name__ = cmd.name.replace("-", "_")
    handler.__doc__ = cmd.help
    handler.__signature__ = inspect.Signature(params)  # type: ignore[attr-defined]
    parent.command(name=cmd.name, help=cmd.help)(handler)


@app.callback()
def root(
    ctx: typer.Context,
    open_id: Annotated[Optional[str], typer.Option("--open-id", envvar="MEO_OPEN_ID", help="飞书 openId，Header X-Feishu-Open-Id")] = None,
    supplier_id: Annotated[Optional[str], typer.Option("--supplier-id", envvar="MEO_SUPPLIER_ID", help="供应商 ID，Header X-Supplier-Id")] = None,
    api_key: Annotated[Optional[str], typer.Option("--api-key", envvar="MEO_API_KEY", help="mo_{32位}，第二优先级")] = None,
    base_url: Annotated[Optional[str], typer.Option("--base-url", envvar="MEO_ADAPTER_BASE_URL", help="adapter Base URL")] = None,
    timeout: Annotated[Optional[float], typer.Option("--timeout", envvar="MEO_ADAPTER_TIMEOUT", help="HTTP 超时秒数")] = None,
) -> None:
    """身份优先 --open-id + --supplier-id，其次 --api-key / MEO_API_KEY。也可写进 .env。"""
    ctx.obj = {
        "open_id": open_id,
        "supplier_id": supplier_id,
        "api_key": api_key,
        "base_url": base_url,
        "timeout": timeout,
    }


_groups: dict[str, typer.Typer] = {}
for _cmd in COMMANDS:
    if not _cmd.group:
        _register(_cmd, app)
        continue
    if _cmd.group not in _groups:
        sub = typer.Typer(help=f"{_cmd.group} 相关命令", no_args_is_help=True)
        _groups[_cmd.group] = sub
        app.add_typer(sub, name=_cmd.group)
    _register(_cmd, _groups[_cmd.group])
