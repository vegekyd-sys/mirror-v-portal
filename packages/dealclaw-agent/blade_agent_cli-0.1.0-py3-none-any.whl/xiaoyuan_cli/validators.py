"""入参校验（与 MCP AroundDeal / 部分 Skill 对齐）。"""

from __future__ import annotations

from typing import Any


def _filled(*values: Any) -> bool:
    return any(str(v or "").strip() for v in values)


def require_any(*keys: str):
    def _fn(body: dict[str, Any]) -> str | None:
        if any(_filled(body.get(k)) for k in keys):
            return None
        return "至少填一项: " + " / ".join(keys)

    return _fn


def arounddeal_company_id(body: dict[str, Any]) -> str | None:
    if _filled(body.get("linkedinUrl"), body.get("website"), body.get("name")):
        return None
    return "linkedin-url / website / name 至少填一项"


def arounddeal_find_limit(body: dict[str, Any]) -> str | None:
    err = arounddeal_company_id(body)
    if err:
        return err
    limit = body.get("limit", 5)
    try:
        n = int(limit)
    except (TypeError, ValueError):
        return "limit 须为整数"
    if n < 1 or n > 5:
        return "limit 须在 1~5"
    return None


def arounddeal_person(body: dict[str, Any]) -> str | None:
    if _filled(body.get("linkedinUrl")) or _filled(body.get("email")):
        return None
    if _filled(body.get("name")) and _filled(body.get("company")):
        return None
    return "至少提供 linkedin-url，或 email，或 name+company"


def arounddeal_resume(body: dict[str, Any]) -> str | None:
    if _filled(body.get("linkedinUrl"), body.get("email")):
        return None
    return "linkedin-url 或 email 至少填一项"


def arounddeal_intel(body: dict[str, Any]) -> str | None:
    t = str(body.get("type") or "").strip().lower()
    allowed = {"clients", "suppliers", "events", "products", "jobs", "orgchart"}
    if t not in allowed:
        return "type 须为 " + " / ".join(sorted(allowed))
    if t in ("jobs", "orgchart"):
        if not _filled(body.get("linkedinUrl"), body.get("website"), body.get("name")):
            return "jobs/orgchart 至少提供 linkedin-url / website / name"
    elif not _filled(body.get("website"), body.get("name")):
        return "至少提供 name 或 website"
    return None


def arounddeal_relationship(body: dict[str, Any]) -> str | None:
    if _filled(body.get("nameA")) and _filled(body.get("nameB")):
        return None
    if _filled(body.get("websiteA")) and _filled(body.get("websiteB")):
        return None
    if _filled(body.get("companyA")) and _filled(body.get("companyB")):
        return None
    return "至少提供 name-a+name-b 或 website-a+website-b"


def company_edit(body: dict[str, Any]) -> str | None:
    if body:
        return None
    return "至少提供一个要改的字段"


def customer_file(body: dict[str, Any]) -> str | None:
    if _filled(body.get("taxNumber"), body.get("companyName")):
        return None
    return "tax-number 与 company-name 至少填一个"


def hunter_email_finder(body: dict[str, Any]) -> str | None:
    if not _filled(body.get("domain"), body.get("company"), body.get("linkedinHandle")):
        return "domain / company / linkedin-handle 至少填一项"
    if _filled(body.get("linkedinHandle")) or _filled(body.get("fullName")):
        return None
    if _filled(body.get("firstName")) and _filled(body.get("lastName")):
        return None
    return "至少提供 first-name+last-name、full-name 或 linkedin-handle"


def hunter_domain_or_company(body: dict[str, Any]) -> str | None:
    if _filled(body.get("domain"), body.get("company")):
        return None
    return "domain / company 至少填一项（domain 优先）"


def hunter_people_find(body: dict[str, Any]) -> str | None:
    if _filled(body.get("email"), body.get("linkedinHandle")):
        return None
    return "email / linkedin-handle 至少填一项"


def apollo_domain(body: dict[str, Any]) -> str | None:
    if _filled(body.get("domain")):
        return None
    return "domain 不能为空"


def apollo_enrich_person(body: dict[str, Any]) -> str | None:
    if _filled(body.get("firstName")) and _filled(body.get("lastName")):
        return None
    if _filled(body.get("fullName")) or _filled(body.get("email")):
        return None
    return "至少提供 first-name+last-name / full-name / email 之一"


def apollo_reveal_contacts(body: dict[str, Any]) -> str | None:
    contacts = body.get("contacts")
    if isinstance(contacts, list) and contacts:
        return None
    return "contacts 不能为空（格式 first:last:domain[:org]，多条用分号分隔）"


def apollo_keyword(body: dict[str, Any]) -> str | None:
    if _filled(body.get("keyword")):
        return None
    return "keyword 不能为空"


def hunter_discover(body: dict[str, Any]) -> str | None:
    if _filled(
        body.get("query"),
        body.get("industry"),
        body.get("headcount"),
        body.get("companyType"),
        body.get("country"),
    ):
        return None
    return "query / industry / headcount / company-type / country 至少填一项"
