"""运行配置。身份从环境变量或 CLI 参数注入。

`.env` 不依赖当前工作目录：优先读 CLI 项目根（editable 安装），再读 cwd。
已存在的进程环境变量不覆盖。
"""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


def _cli_root() -> Path | None:
    here = Path(__file__).resolve()
    for root in (here.parents[2], here.parents[1], here.parent):
        if (root / "pyproject.toml").is_file() or (root / ".env").is_file():
            return root
    return None


def _read_env_file(path: Path) -> dict[str, str]:
    if not path.is_file():
        return {}
    out: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key:
            out[key] = value
    return out


def _preload_dotenv() -> None:
    """把项目根 / cwd 的 .env 灌进 os.environ（不覆盖已有环境变量）。"""
    preset = set(os.environ)
    merged: dict[str, str] = {}
    root = _cli_root()
    if root is not None:
        merged.update(_read_env_file(root / ".env"))
    cwd_env = Path.cwd() / ".env"
    if cwd_env.is_file():
        merged.update(_read_env_file(cwd_env))
    for key, value in merged.items():
        if key not in preset:
            os.environ[key] = value


_preload_dotenv()


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        extra="ignore",
        populate_by_name=True,
    )

    adapter_base_url: str = Field(
        default="https://micro.tradechina.com/blade-agent-adapter",
        validation_alias="MEO_ADAPTER_BASE_URL",
    )
    open_id: str = Field(default="", validation_alias="MEO_OPEN_ID")
    supplier_id: str = Field(default="", validation_alias="MEO_SUPPLIER_ID")
    api_key: str = Field(default="", validation_alias="MEO_API_KEY")
    adapter_timeout: float = Field(default=60.0, validation_alias="MEO_ADAPTER_TIMEOUT")


@lru_cache
def get_settings() -> Settings:
    return Settings()
