"""调用 blade-agent-adapter 的 HTTP 客户端（同步，给 CLI 用）。"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import httpx

from xiaoyuan_cli.config import Settings


class AdapterError(Exception):
    """下游不可达或响应不是 JSON。"""


def auth_mode(settings: Settings) -> str:
    """feishu：Header 飞书身份；apiKey：X-Api-Key；none：都没配。"""
    open_id = (settings.open_id or "").strip()
    supplier_id = (settings.supplier_id or "").strip()
    if open_id and supplier_id:
        return "feishu"
    if (settings.api_key or "").strip():
        return "apiKey"
    return "none"


def _headers(settings: Settings) -> dict[str, str]:
    """
    1. 同时有 openId + supplierId → 只带飞书 Header（不带 apiKey，避免 adapter 用 key 盖掉身份）
    2. 否则带 X-Api-Key
    """
    headers = {"Accept": "application/json"}
    open_id = (settings.open_id or "").strip()
    supplier_id = (settings.supplier_id or "").strip()
    if open_id and supplier_id:
        headers["X-Feishu-Open-Id"] = open_id
        headers["X-Supplier-Id"] = supplier_id
        return headers
    if open_id or supplier_id:
        raise AdapterError(
            "飞书身份须同时提供 --open-id 与 --supplier-id"
            "（或环境变量 MEO_OPEN_ID / MEO_SUPPLIER_ID），对应 Header X-Feishu-Open-Id / X-Supplier-Id"
        )
    api_key = (settings.api_key or "").strip()
    if api_key:
        headers["X-Api-Key"] = api_key
        return headers
    raise AdapterError(
        "缺少身份：优先传 --open-id + --supplier-id（Header X-Feishu-Open-Id / X-Supplier-Id），"
        "或配置 MEO_API_KEY / --api-key"
    )


def post_json(
    settings: Settings,
    path: str,
    body: Any | None = None,
    *,
    timeout: float | None = None,
) -> dict[str, Any]:
    url = settings.adapter_base_url.rstrip("/") + path
    wait = timeout if timeout is not None else settings.adapter_timeout
    headers = _headers(settings)
    headers["Content-Type"] = "application/json; charset=utf-8"
    payload = None if body is None else json.dumps(body, ensure_ascii=False)

    try:
        with httpx.Client(timeout=wait) as client:
            response = client.post(url, content=payload, headers=headers)
    except httpx.TimeoutException as e:
        raise AdapterError(f"调用 adapter 超时（{wait}s）: {path}") from e
    except httpx.RequestError as e:
        raise AdapterError(f"无法连接 adapter: {e}") from e

    return _parse_response(response)


def post_multipart_file(
    settings: Settings,
    path: str,
    file_path: str,
    *,
    field_name: str = "file",
    timeout: float | None = None,
) -> dict[str, Any]:
    url = settings.adapter_base_url.rstrip("/") + path
    wait = timeout if timeout is not None else max(settings.adapter_timeout, 180)
    headers = _headers(settings)
    p = Path(file_path)
    try:
        with httpx.Client(timeout=wait) as client:
            with p.open("rb") as fh:
                response = client.post(
                    url,
                    headers=headers,
                    files={field_name: (p.name, fh, "application/octet-stream")},
                )
    except httpx.TimeoutException as e:
        raise AdapterError(f"调用 adapter 超时（{wait}s）: {path}") from e
    except httpx.RequestError as e:
        raise AdapterError(f"无法连接 adapter: {e}") from e

    return _parse_response(response)


def _parse_response(response: httpx.Response) -> dict[str, Any]:
    text = response.text or ""
    try:
        data = json.loads(text) if text.strip() else {}
    except json.JSONDecodeError:
        raise AdapterError(
            f"adapter 返回非 JSON，HTTP {response.status_code}: {text[:500]}"
        )
    if isinstance(data, dict):
        return data
    return {"success": False, "msg": "adapter 响应不是对象", "data": data}
