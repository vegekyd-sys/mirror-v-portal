"""小元 CLI：直连 blade-agent-adapter。"""

__version__ = "0.1.0"
