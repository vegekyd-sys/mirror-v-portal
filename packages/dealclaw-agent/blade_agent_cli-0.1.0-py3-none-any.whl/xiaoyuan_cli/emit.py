"""stdout 只打 JSON。"""

from __future__ import annotations

import json
import sys
from typing import Any


def emit(payload: Any) -> None:
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def emit_error(msg: str) -> None:
    emit({"success": False, "msg": msg, "data": None})


def configure_stdio() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8")
