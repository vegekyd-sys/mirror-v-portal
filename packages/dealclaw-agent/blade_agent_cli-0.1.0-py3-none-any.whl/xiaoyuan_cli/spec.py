"""命令目录数据结构。"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Literal

Kind = Literal["str", "int", "bool", "csv_str", "csv_int", "file", "apollo_contacts"]

ValidateFn = Callable[[dict[str, Any]], str | None]


@dataclass(frozen=True)
class Arg:
    name: str
    json_key: str
    kind: Kind = "str"
    required: bool = False
    default: Any = None
    help: str = ""
    omit_empty: bool = True


@dataclass(frozen=True)
class Command:
    group: str
    name: str
    help: str
    path: str | None = None
    args: tuple[Arg, ...] = field(default_factory=tuple)
    timeout: float = 60
    validate: ValidateFn | None = None
    special: str | None = None
    multipart_field: str | None = None
