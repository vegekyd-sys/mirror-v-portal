"""入口。"""

from __future__ import annotations

from xiaoyuan_cli.emit import configure_stdio


def main() -> None:
    configure_stdio()
    from xiaoyuan_cli.app import app

    app()


if __name__ == "__main__":
    main()
