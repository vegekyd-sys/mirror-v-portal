"""命令目录数据结构。"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Literal

Kind = Literal["str", "int", "bool", "csv_str", "csv_int", "json", "file", "apollo_contacts"]

ValidateFn = Callable[[dict[str, Any]], str | None]


@dataclass(frozen=True)
class Arg:
    name: str
    json_key: str
    kind: Kind = "str"
    required: bool = False
    default: Any = None
    help: str = ""
    omit_empty: bool = True
    # (value, description)；空元组表示开放取值，schema 里 enum 为 null
    enum: tuple[tuple[Any, str], ...] = ()


@dataclass(frozen=True)
class Command:
    group: str
    name: str
    help: str
    path: str | None = None
    args: tuple[Arg, ...] = field(default_factory=tuple)
    timeout: float = 60
    validate: ValidateFn | None = None
    special: str | None = None
    multipart_field: str | None = None
