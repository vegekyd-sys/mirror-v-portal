"""把 Command 编成 agent 可解析的参数 JSON。"""

from __future__ import annotations

from typing import Any

from xiaoyuan_cli.spec import Arg, Command, Kind

_TYPE: dict[Kind, str] = {
    "str": "string",
    "int": "integer",
    "bool": "boolean",
    "csv_str": "csv_string",
    "csv_int": "csv_integer",
    "json": "json",
    "file": "file",
    "apollo_contacts": "apollo_contacts",
}


def _arg_schema(arg: Arg) -> dict[str, Any]:
    item: dict[str, Any] = {
        "name": arg.name,
        "type": _TYPE.get(arg.kind, arg.kind),
        "required": arg.required,
        "description": arg.help or arg.json_key,
        "enum": (
            [{"value": value, "description": label} for value, label in arg.enum]
            if arg.enum
            else None
        ),
    }
    if arg.default is not None:
        item["default"] = arg.default
    return item


def command_schema(cmd: Command) -> dict[str, Any]:
    command = cmd.name if not cmd.group else f"{cmd.group} {cmd.name}"
    return {
        "command": command,
        "group": cmd.group or None,
        "name": cmd.name,
        "description": cmd.help,
        "path": cmd.path,
        "args": [_arg_schema(a) for a in cmd.args],
    }


def catalog_schema(commands: tuple[Command, ...]) -> dict[str, Any]:
    return {"commands": [command_schema(c) for c in commands]}
