"""Thin HTTP client for the 星擎 backend REST API.

Only read-only endpoints are wrapped. Tenant scoping is the server's job: the
client never fabricates an identity and never trusts a locally supplied tenant
id as authorization.

Verified backend contract (2026-09-11, live production):

* envelope: ``{"responseCode","success","responseMsg","result","time"}``
* auth: ``satoken: <token>`` header (token from ``POST /api/auth/login``)
* password: AES-128/ECB/PKCS5Padding, base64 output, fixed product key
"""

from __future__ import annotations

import base64
import json
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Dict, List, Optional

from .errors import (
    API_ERROR,
    AUTH_EXPIRED,
    AUTH_FAILED,
    BACKEND_CODE_MAP,
    NETWORK_ERROR,
    CliError,
)

# AES key used by the 星擎 client (identical to the browser/Java AESUtil).
_PASSWORD_KEY_B64 = "4HQY2EpNhyM6V8REPR4p6A=="

_TIMEOUT = 30
_RETRIES = 2


def encrypt_password(password: str) -> str:
    """AES-128/ECB/PKCS5Padding + base64, matching the 星擎 frontend."""
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    except ImportError as exc:  # pragma: no cover - dependency is declared
        raise CliError(
            "CONFIG_ERROR",
            "缺少依赖 cryptography，请重新安装：pip install 'cryptography>=41'",
        ) from exc

    key = base64.b64decode(_PASSWORD_KEY_B64)
    raw = password.encode("utf-8")
    pad = 16 - (len(raw) % 16)
    padded = raw + bytes([pad]) * pad
    encryptor = Cipher(algorithms.AES(key), modes.ECB()).encryptor()
    return base64.b64encode(encryptor.update(padded) + encryptor.finalize()).decode("ascii")


class Client:
    """Stateless-per-call client; ``token`` may be swapped after login."""

    def __init__(self, base_url: str, token: Optional[str] = None, timeout: int = _TIMEOUT) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout = timeout

    # -- transport -------------------------------------------------------
    def request(
        self,
        method: str,
        path: str,
        body: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        token: Optional[str] = None,
        expect_auth: bool = True,
    ) -> Any:
        from .output import log as _log
        _t0 = time.perf_counter()
        url = f"{self.base_url}{path}"
        _log("http > %s %s %s" % (method.upper(), path, {k: v for k, v in (body or {}).items() if k in ("pageNo","pageSize","enterpriseId","account","startDate","endDate","source")}))
        if params:
            clean = {k: v for k, v in params.items() if v is not None}
            if clean:
                url = f"{url}?{urllib.parse.urlencode(clean)}"

        use_token = token if token is not None else self.token
        payload = None
        if body is not None:
            payload = json.dumps(body, ensure_ascii=False).encode("utf-8")

        last_error: Optional[Exception] = None
        for attempt in range(_RETRIES + 1):
            request = urllib.request.Request(url, data=payload, method=method.upper())
            request.add_header("Content-Type", "application/json")
            request.add_header("Accept", "application/json")
            if use_token:
                request.add_header("satoken", use_token)
            try:
                with urllib.request.urlopen(request, timeout=self.timeout) as response:
                    raw = response.read().decode("utf-8", "replace")
                    _log("http < %s %s status=%s %dB %.2fs" % (method.upper(), path, getattr(response, "status", "?"), len(raw), time.perf_counter() - _t0))
                break
            except urllib.error.HTTPError as exc:
                detail = exc.read().decode("utf-8", "replace")[:400]
                if exc.code in (404, 405):
                    raise CliError(
                        API_ERROR,
                        f"后端接口不存在或方法不允许（HTTP {exc.code}）",
                        details={"path": path, "method": method, "body": detail},
                    ) from exc
                if exc.code >= 500 and attempt < _RETRIES:
                    last_error = CliError(API_ERROR, f"HTTP {exc.code} {detail}", details={"path": path})
                    time.sleep(0.4 * (attempt + 1))
                    continue
                raise CliError(
                    API_ERROR,
                    f"后端返回 HTTP {exc.code}",
                    details={"path": path, "method": method, "body": detail},
                ) from exc
            except urllib.error.URLError as exc:
                last_error = CliError(
                    NETWORK_ERROR,
                    f"无法连接后端 {self.base_url}: {exc.reason}",
                    details={"path": path, "base_url": self.base_url},
                    hint="检查网络/DNS；或设置 XINGQING_BASE_URL 指向可达环境。",
                )
                if attempt < _RETRIES:
                    time.sleep(0.4 * (attempt + 1))
                    continue
                raise last_error
            except OSError as exc:  # timeouts surface here
                last_error = CliError(
                    NETWORK_ERROR,
                    f"请求超时或被中断: {exc}",
                    details={"path": path, "timeout_s": self.timeout},
                )
                if attempt < _RETRIES:
                    time.sleep(0.4 * (attempt + 1))
                    continue
                raise last_error
        else:  # pragma: no cover - defensive
            raise last_error or CliError(NETWORK_ERROR, "未知网络错误")

        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise CliError(
                API_ERROR,
                "后端返回了非 JSON 响应",
                details={"path": path, "body": raw[:200]},
            ) from exc

        if not isinstance(data, dict):
            raise CliError(API_ERROR, "后端返回结构异常", details={"path": path})

        code = str(data.get("responseCode") or "")
        if data.get("success") is True:
            return data.get("result")

        message = data.get("responseMsg") or f"后端返回失败（responseCode={code}）"
        if code in BACKEND_CODE_MAP:
            mapped, _ = BACKEND_CODE_MAP[code]
            if mapped == AUTH_EXPIRED:
                if not expect_auth:
                    raise CliError(mapped, message, details={"path": path})
                raise CliError(
                    mapped,
                    "登录凭证无效或已过期",
                    details={"path": path, "backend_message": message},
                    hint="运行 `xingqing-cli login` 重新登录。",
                )
            raise CliError(AUTH_FAILED, message, details={"path": path, "responseCode": code})
        if code == "401":
            raise CliError(AUTH_EXPIRED, message, details={"path": path})
        raise CliError(
            API_ERROR,
            message,
            details={"path": path, "responseCode": code},
        )

    # -- endpoints -------------------------------------------------------
    def login(self, username: str, password: str) -> Dict[str, Any]:
        result = self.request(
            "POST",
            "/api/auth/login",
            {"account": username, "password": encrypt_password(password)},
            expect_auth=False,
        )
        if not isinstance(result, dict) or not result.get("token"):
            raise CliError(AUTH_FAILED, "登录成功但响应缺少 token", details={"keys": sorted((result or {}).keys())})
        return result

    def get_current_user(self, token: Optional[str] = None) -> Dict[str, Any]:
        result = self.request("GET", "/api/auth/getCurrentUserInfo", token=token)
        return result if isinstance(result, dict) else {}

    def logout(self, token: Optional[str] = None) -> Any:
        try:
            return self.request("POST", "/api/auth/logout", token=token)
        except CliError:
            # Logout is best-effort: local token removal still proceeds.
            return None

    def account_list(self) -> List[str]:
        result = self.request("GET", "/api/devices/getAccountList")
        return result if isinstance(result, list) else []

    def video_count_info(self) -> Dict[str, Any]:
        result = self.request("GET", "/api/devices/getVideoCountInfo")
        return result if isinstance(result, dict) else {}

    def video_list_page(
        self,
        page_no: int = 1,
        page_size: int = 20,
        enterprise_id: Optional[int] = None,
        account: Optional[str] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"pageNo": page_no, "pageSize": page_size}
        if enterprise_id is not None:
            body["enterpriseId"] = enterprise_id
        if account:
            body["account"] = account
        result = self.request("POST", "/api/devices/getVideoListPage", body)
        return result if isinstance(result, dict) else {}

    def search_info(self, start_date: str, end_date: str, account: str = "") -> Dict[str, Any]:
        result = self.request(
            "POST",
            "/api/devices/searchInfo",
            {"startDate": start_date, "endDate": end_date, "account": account},
        )
        return result if isinstance(result, dict) else {}

    def lead_page(self, page_no: int = 0, page_size: int = 20, source: Optional[str] = None) -> Dict[str, Any]:
        body: Dict[str, Any] = {"pageNo": page_no, "pageSize": page_size}
        if source:
            body["source"] = source
        result = self.request("POST", "/api/business/selectPage", body)
        return result if isinstance(result, dict) else {}

    def hot_video_page(self, kind: str = "client", page_no: int = 0, page_size: int = 20) -> Dict[str, Any]:
        path = (
            "/api/hotVideo/page/queryPageClientList"
            if kind == "client"
            else "/api/hotVideo/page/queryPageHotProductList"
        )
        result = self.request("POST", path, {"pageNo": page_no, "pageSize": page_size})
        return result if isinstance(result, dict) else {}
