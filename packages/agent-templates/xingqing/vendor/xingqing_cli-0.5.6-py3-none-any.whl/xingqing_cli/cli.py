"""Command-line entry point.

Argument parsing + envelope contract. All failure paths emit a stable error
code; tracebacks are never printed to stdout.
"""

from __future__ import annotations

import argparse
import sys
import time
import traceback
from typing import Any, List, Optional

from . import __version__, commands, output, registry
from .errors import EXIT_ERROR, EXIT_OK, EXIT_USAGE, INVALID_ARG, CliError
from . import credentials

PROG = "xingqing-cli"


class _Parser(argparse.ArgumentParser):
    """argparse that raises instead of calling sys.exit on usage errors."""

    def error(self, message: str):  # type: ignore[override]
        raise CliError(INVALID_ARG, message, exit_code=EXIT_USAGE, hint=f"运行 `{PROG} commands` 查看全部命令。")

    def exit(self, status: int = 0, message: Optional[str] = None):  # type: ignore[override]
        if message:
            sys.stderr.write(message)
        raise SystemExit(status)


def _add_output_flags(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--format",
        choices=["json", "table", "jsonl"],
        default=argparse.SUPPRESS,
        help="Output format (default json).",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        default=argparse.SUPPRESS,
        help="Alias for --format json.",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = _Parser(
        prog=PROG,
        description="星擎 (Xingqing) agent-first read-only CLI. Machine-readable JSON on stdout, diagnostics on stderr.",
    )
    parser.add_argument("--base-url", dest="base_url", help="Override backend base URL.")
    parser.add_argument("--format", choices=["json", "table", "jsonl"], default="json", help="Output format: json (envelope), table, jsonl (one row per line + final _meta).")
    parser.add_argument("--json", action="store_true", help="Alias for --format json.")
    parser.add_argument("--debug", action="store_true", help="Print tracebacks to stderr.")
    parser.add_argument("--version", action="version", version=f"{PROG} {__version__}")

    sub = parser.add_subparsers(dest="command", metavar="COMMAND")

    # status
    p = sub.add_parser("status", help="Service/auth/version self-check.")
    p.add_argument("--no-network", action="store_true", help="Local configuration only.")
    _add_output_flags(p)

    # login
    p = sub.add_parser("login", help="Authenticate and cache the session token.")
    p.add_argument("--username", help="星擎 account (or $XINGQING_USERNAME).")
    p.add_argument("--password-stdin", action="store_true", help="Read password from stdin.")
    p.add_argument("--no-cache", action="store_true", help="Do not write the local profile.")
    _add_output_flags(p)

    # logout
    p = sub.add_parser("logout", help="Invalidate session and delete cached token.")
    _add_output_flags(p)

    # discovery
    p = sub.add_parser("commands", help="Self-discovery: list commands.")
    _add_output_flags(p)
    p = sub.add_parser("schema", help="Self-discovery: parameter schema (optionally for one command).")
    p.add_argument("command_name", nargs="*", metavar="COMMAND", help="Limit output to a single command (e.g. `schema video list`).")
    _add_output_flags(p)

    # account
    p = sub.add_parser("account", help="Account queries.")
    account_sub = p.add_subparsers(dest="account_command", metavar="SUBCOMMAND")
    ap = account_sub.add_parser("list", help="List visible accounts.")
    ap.add_argument("--platform", help="tiktok|youtube|facebook|instagram (aliases: tt|yt|fb|ig).")
    ap.add_argument("--enterprise", help="Enterprise name or numeric enterpriseId.")
    ap.add_argument("--limit", type=int, default=0, help="Max accounts (0 = all).")
    ap.add_argument("--scan-limit", type=int, default=200, help="Max accounts probed for --platform.")
    _add_output_flags(ap)

    aps = account_sub.add_parser("stats", help="Per-account performance (aggregated client-side).")
    aps.add_argument("--account", help="Restrict to one account.")
    aps.add_argument("--limit", type=int, default=20, help="Max account rows (1-200).")
    aps.add_argument("--max-pages", dest="max_pages", type=int, default=60, help="Page cap for the client-side scan (pageSize 200).")
    _add_output_flags(aps)

    # video
    p = sub.add_parser("video", help="Published-video queries.")
    video_sub = p.add_subparsers(dest="video_command", metavar="SUBCOMMAND")

    vc = video_sub.add_parser("count", help="Aggregated metrics.")
    vc.add_argument("--enterprise", help="Enterprise name or numeric enterpriseId.")
    vc.add_argument("--account", help="Restrict to one account.")
    vc.add_argument("--platform", help="Platform filter (derived from shareLink).")
    vc.add_argument("--max-pages", type=int, default=60, help="Scan page cap (pageSize 200).")
    _add_output_flags(vc)

    vl = video_sub.add_parser("list", help="List published videos.")
    vl.add_argument("--enterprise", help="Enterprise name or numeric enterpriseId.")
    vl.add_argument("--account", help="Restrict to one account.")
    vl.add_argument("--platform", help="Platform filter (derived from shareLink).")
    vl.add_argument("--country", help="Country code filter, e.g. BR (client-side scan).")
    vl.add_argument("--sort", choices=["play", "like", "comment", "share", "publish"], help="Sort scanned rows desc by that metric (requires a scan).")
    vl.add_argument("--limit", type=int, default=20, help="Max rows to output (1-5000). Auto-paginates until it has that many.")
    vl.add_argument("--page", type=int, default=None, help="Start page (default 1). With --page, the legacy 'page N of --limit rows' shape is kept.")
    vl.add_argument("--page-size", dest="page_size", type=int, default=None, help="Rows requested per backend call (1-200, default 200).")
    vl.add_argument("--no-paginate", dest="no_paginate", action="store_true", help="Fetch exactly one page and report next_page instead of auto-paging.")
    vl.add_argument("--max-pages", type=int, default=60, help="Scan page cap for --platform/--country/--sort (pageSize per --page-size).")
    vl.add_argument("--raw", action="store_true", help="Return untrimmed backend rows.")
    _add_output_flags(vl)

    # lead（线索/询盘）
    p = sub.add_parser("lead", help="Lead (inquiry) queries.")
    lead_sub = p.add_subparsers(dest="lead_command", metavar="SUBCOMMAND")
    ll = lead_sub.add_parser("list", help="List leads (inquiries), newest first.")
    ll.add_argument("--page", type=int, default=None, help="Start page (1-based, default 1).")
    ll.add_argument("--limit", type=int, default=20, help="Max rows to output (1-5000). Auto-paginates until it has that many.")
    ll.add_argument("--page-size", dest="page_size", type=int, default=None, help="Rows requested per backend call (1-200, default 200).")
    ll.add_argument("--no-paginate", dest="no_paginate", action="store_true", help="Fetch exactly one page and report next_page instead of auto-paging.")
    ll.add_argument("--source", help="Filter by lead source code.")
    ll.add_argument("--partner", help="Filter by partnerId (企业), comma-separated; filtered client-side.")
    _add_output_flags(ll)

    # trend（日粒度趋势）
    p = sub.add_parser("trend", help="Daily trend charts (plays / followers / likes / comments / shares).")
    p.add_argument("--start", help="Start date YYYY-MM-DD (default: 6 days ago).")
    p.add_argument("--end", help="End date YYYY-MM-DD (default: today).")
    p.add_argument("--account", help="Restrict to one account.")
    _add_output_flags(p)

    # hot-video（热品洞察）
    p = sub.add_parser("hot-video", help="Hot video / hot product discovery lists.")
    hv_sub = p.add_subparsers(dest="hot_command", metavar="SUBCOMMAND")
    hl = hv_sub.add_parser("list", help="List hot videos.")
    hl.add_argument("--scope", choices=["client", "product"], default="client", help="client = 客户向, product = 热品榜.")
    hl.add_argument("--page", type=int, default=None, help="Start page (1-based, default 1).")
    hl.add_argument("--limit", type=int, default=20, help="Max rows to output (1-5000). Auto-paginates until it has that many.")
    hl.add_argument("--page-size", dest="page_size", type=int, default=None, help="Rows requested per backend call (1-200, default 200).")
    hl.add_argument("--no-paginate", dest="no_paginate", action="store_true", help="Fetch exactly one page and report next_page instead of auto-paging.")
    _add_output_flags(hl)

    # selfcheck
    p = sub.add_parser("selfcheck", help="One-shot acceptance check.")
    p.add_argument("--isolation-probe-ids", default="1,65", help="Foreign enterpriseIds for the cross-tenant probe.")
    _add_output_flags(p)

    return parser


def _resolve_command(args: argparse.Namespace) -> str:
    if args.command == "account":
        if not getattr(args, "account_command", None):
            raise CliError(INVALID_ARG, "account 需要一个子命令", exit_code=EXIT_USAGE, hint="例：xingqing-cli account list --platform tiktok")
        return f"account {args.account_command}"
    if args.command == "video":
        if not getattr(args, "video_command", None):
            raise CliError(INVALID_ARG, "video 需要一个子命令", exit_code=EXIT_USAGE, hint="例：xingqing-cli video count --platform tiktok")
        return f"video {args.video_command}"
    if args.command == "lead":
        if not getattr(args, "lead_command", None):
            raise CliError(INVALID_ARG, "lead 需要一个子命令", exit_code=EXIT_USAGE, hint="例：xingqing-cli lead list --limit 20")
        return f"lead {args.lead_command}"
    if args.command == "hot-video":
        if not getattr(args, "hot_command", None):
            raise CliError(INVALID_ARG, "hot-video 需要一个子命令", exit_code=EXIT_USAGE, hint="例：xingqing-cli hot-video list --scope client")
        return f"hot-video {args.hot_command}"
    return args.command or ""


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    argv = list(sys.argv[1:] if argv is None else argv)
    started = time.monotonic()

    # Machine contract: stdout always carries exactly one JSON envelope.
    # Help / no-command are handled explicitly so humans still get readable text
    # (on stderr) while agents still get JSON (on stdout).
    if any(a in ("-h", "--help") for a in argv):
        parser.print_help(sys.stderr)
        output.emit(
            output.envelope(
                data={
                    "usage": f"{PROG} <command> [options]",
                    "commands": [c["name"] for c in registry.commands_payload()],
                },
                error=None,
                meta=output.build_meta("help", started),
            ),
            "json",
        )
        return EXIT_OK

    if any(a in ("-V", "--version") for a in argv):
        output.emit(
            output.envelope(
                data={"name": PROG, "version": __version__},
                error=None,
                meta=output.build_meta("version", started),
            ),
            "json",
        )
        sys.stderr.write(f"{PROG} {__version__}\n")
        return EXIT_OK

    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:  # --version
        return int(exc.code or 0)
    except CliError as exc:
        output.emit(output.envelope(error=exc.to_dict(), meta=output.build_meta("(usage)", started)), "json")
        output.warn(f"{exc.code}: {exc.message}")
        return exc.exit_code

    if not args.command:
        output.emit(
            output.envelope(
                error={
                    "code": INVALID_ARG,
                    "message": "缺少命令",
                    "hint": f"运行 `{PROG} commands` 查看全部命令，或 `{PROG} schema` 查看参数。",
                },
                meta=output.build_meta("(usage)", started),
            ),
            "json",
        )
        output.warn(f"缺少命令；`{PROG} commands` 可列出全部命令。")
        return EXIT_USAGE

    fmt = "json" if getattr(args, "json", False) else getattr(args, "format", "json")
    command = ""
    try:
        command = _resolve_command(args)
        base_url = credentials.base_url(getattr(args, "base_url", None))
        data, extra_meta = commands.dispatch(command, args, base_url)
        meta = output.build_meta(command, started, base_url, extra_meta)
        output.emit(output.envelope(data=data, error=None, meta=meta), fmt)
        if command == "selfcheck" and isinstance(data, dict):
            result = data.get("result") or {}
            return EXIT_ERROR if result.get("failed") else EXIT_OK
        return EXIT_OK
    except CliError as exc:
        meta = output.build_meta(command or "(usage)", started)
        output.emit(output.envelope(error=exc.to_dict(), meta=meta), "json")
        output.warn(f"{exc.code}: {exc.message}")
        if getattr(args, "debug", False):
            traceback.print_exc(file=sys.stderr)
        return exc.exit_code
    except KeyboardInterrupt:
        output.warn("已取消")
        return EXIT_ERROR
    except Exception as exc:  # noqa: BLE001 - converted to a stable envelope
        meta = output.build_meta(command or "(unknown)", started)
        output.emit(
            output.envelope(
                error={"code": "INTERNAL_ERROR", "message": str(exc) or exc.__class__.__name__},
                meta=meta,
            ),
            "json",
        )
        if getattr(args, "debug", False):
            traceback.print_exc(file=sys.stderr)
        return EXIT_ERROR


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
