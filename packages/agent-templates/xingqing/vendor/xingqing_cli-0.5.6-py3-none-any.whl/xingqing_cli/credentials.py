"""Local credential storage.

Two supported sources, in priority order:

1. Environment (agents / CI — nothing touches disk):
   ``XINGQING_USERNAME`` / ``XINGQING_PASSWORD``
2. Cached session profile (interactive use — same idea as ``gh auth login``):
   ``~/.config/xingqing/credentials`` (mode 600, directory mode 700)

The cached profile stores the *session token* handed out by the 星擎 backend.
The plaintext password is never persisted.
"""

from __future__ import annotations

import json
import os
import stat
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from .errors import CONFIG_ERROR, CliError

ENV_USERNAME = "XINGQING_USERNAME"
ENV_PASSWORD = "XINGQING_PASSWORD"
ENV_BASE_URL = "XINGQING_BASE_URL"
ENV_CONFIG_DIR = "XINGQING_CONFIG_DIR"

DEFAULT_BASE_URL = "https://d12.ultronx.tech"


def config_dir() -> Path:
    override = os.environ.get(ENV_CONFIG_DIR)
    if override:
        return Path(override).expanduser()
    return Path.home() / ".config" / "xingqing"


def credentials_path() -> Path:
    return config_dir() / "credentials"


def base_url(cli_value: Optional[str] = None) -> str:
    return (
        cli_value
        or os.environ.get(ENV_BASE_URL)
        or _load().get("base_url")
        or DEFAULT_BASE_URL
    ).rstrip("/")


def env_credentials() -> Optional[Tuple[str, str]]:
    user = os.environ.get(ENV_USERNAME)
    password = os.environ.get(ENV_PASSWORD)
    if user and password:
        return user, password
    return None


def _load() -> Dict[str, Any]:
    path = credentials_path()
    if not path.exists():
        return {}
    try:
        with path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def load_profile() -> Dict[str, Any]:
    """Return the cached profile (``{}`` when nothing is stored or it is unreadable)."""
    return _load()


def save_profile(profile: Dict[str, Any]) -> Path:
    """Persist the profile with restrictive permissions (file 600, dir 700)."""
    directory = config_dir()
    try:
        directory.mkdir(parents=True, exist_ok=True)
        os.chmod(directory, stat.S_IRWXU)
        path = credentials_path()
        payload = json.dumps(profile, ensure_ascii=False, indent=2) + "\n"
        # Create with 600 from the start: never leave a readable window.
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, stat.S_IRUSR | stat.S_IWUSR)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(payload)
        os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
        return path
    except OSError as exc:  # pragma: no cover - depends on host FS policy
        raise CliError(
            CONFIG_ERROR,
            f"无法写入凭证文件: {exc}",
            details={"path": str(credentials_path())},
            hint="检查 XINGQING_CONFIG_DIR / HOME 的写权限，或改用环境变量。",
        ) from exc


def clear_profile() -> bool:
    path = credentials_path()
    if path.exists():
        try:
            path.unlink()
            return True
        except OSError as exc:  # pragma: no cover
            raise CliError(CONFIG_ERROR, f"无法删除凭证文件: {exc}") from exc
    return False


def cached_token() -> Optional[str]:
    token = _load().get("token")
    return token if isinstance(token, str) and token else None
