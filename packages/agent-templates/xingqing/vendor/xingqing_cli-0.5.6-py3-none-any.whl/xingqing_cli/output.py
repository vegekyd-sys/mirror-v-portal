"""Output contract.

* stdout carries exactly one machine-readable JSON envelope:
  ``{"data": ..., "error": null, "meta": {...}}``
* diagnostics / progress go to stderr
* failures use stable error codes and never expose tracebacks on stdout
"""

from __future__ import annotations

from datetime import datetime

import json
import os
import sys
import time
from typing import Any, Dict, List, Optional

from . import __version__


def envelope(
    data: Any = None,
    error: Optional[Dict[str, Any]] = None,
    meta: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    return {"data": data, "error": error, "meta": meta or {}}


def build_meta(
    command: str,
    started_at: float,
    base_url: Optional[str] = None,
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    meta: Dict[str, Any] = {
        "command": command,
        "version": __version__,
        "duration_ms": round((time.monotonic() - started_at) * 1000, 1),
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
    }
    if base_url:
        meta["base_url"] = base_url
    if extra:
        meta.update(extra)
    return meta


def emit(payload: Dict[str, Any], fmt: str = "json") -> None:
    if fmt == "json":
        json.dump(payload, sys.stdout, ensure_ascii=False, indent=2)
        sys.stdout.write("\n")
        sys.stdout.flush()
        return
    if fmt == "table":
        _emit_table(payload)
        return
    if fmt == "jsonl":
        _emit_jsonl(payload)
        return
    raise ValueError(f"unknown format: {fmt}")


def _emit_jsonl(payload: Dict[str, Any]) -> None:
    """Stream rows as one JSON object per line; the envelope meta goes last.

    Designed for large result sets: an agent can process row by row without
    buffering a giant array, while the trailing `_meta` line still carries the
    pagination/truncation contract.
    """
    error = payload.get("error")
    if error:
        sys.stdout.write(json.dumps({"error": error}, ensure_ascii=False) + "\n")
        sys.stdout.flush()
        return
    data = payload.get("data")
    rows = _rows_of(data)
    if rows is None:
        sys.stdout.write(json.dumps(data, ensure_ascii=False) + "\n")
    else:
        for row in rows:
            sys.stdout.write(json.dumps(row, ensure_ascii=False) + "\n")
    sys.stdout.write(json.dumps({"_meta": payload.get("meta") or {}}, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def _emit_table(payload: Dict[str, Any]) -> None:
    data = payload.get("data")
    error = payload.get("error")
    if error:
        sys.stdout.write(f"ERROR {error.get('code')}: {error.get('message')}\n")
        sys.stdout.flush()
        return
    rows = _rows_of(data)
    if rows is None:
        sys.stdout.write(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
        sys.stdout.flush()
        return
    if not rows:
        sys.stdout.write("(no rows)\n")
        sys.stdout.flush()
        return
    columns: List[str] = []
    for row in rows:
        for key in row:
            if key not in columns:
                columns.append(key)
    widths = {c: len(str(c)) for c in columns}
    for row in rows:
        for c in columns:
            widths[c] = max(widths[c], len(_cell(row.get(c))))
    header = "  ".join(str(c).ljust(widths[c]) for c in columns)
    sys.stdout.write(header + "\n")
    sys.stdout.write("-" * len(header) + "\n")
    for row in rows:
        sys.stdout.write("  ".join(_cell(row.get(c)).ljust(widths[c]) for c in columns) + "\n")
    sys.stdout.flush()


def _rows_of(data: Any) -> Optional[List[Dict[str, Any]]]:
    if isinstance(data, list) and all(isinstance(item, dict) for item in data):
        return data
    if isinstance(data, dict):
        for key in ("items", "videos", "accounts", "rows"):
            value = data.get(key)
            if isinstance(value, list) and all(isinstance(item, dict) for item in value):
                return value
    return None


def _cell(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def warn(message: str) -> None:
    sys.stderr.write(f"[xingqing-cli] {message}\n")
    sys.stderr.flush()


_DEBUG = os.environ.get("XINGQING_DEBUG", "").strip() not in ("", "0", "false", "False")
_LOG_FILE = os.environ.get("XINGQING_LOG_FILE", "").strip()


def log(message: str) -> None:
    """诊断日志（默认关闭）：XINGQING_DEBUG=1 → stderr；XINGQING_LOG_FILE=<路径> → 追加文件。"""
    if not _DEBUG and not _LOG_FILE:
        return
    line = f"[xingqing-cli][{datetime.now().strftime('%H:%M:%S')}] {message}"
    if _DEBUG:
        sys.stderr.write(line + "\n"); sys.stderr.flush()
    if _LOG_FILE:
        try:
            with open(_LOG_FILE, "a", encoding="utf-8") as fh: fh.write(line + "\n")
        except OSError:
            pass
