"""Single source of truth for self-discovery (``commands`` / ``schema``).

Every entry here is backed by an endpoint that was verified against production
on 2026-09-11. Unknown endpoints are deliberately absent.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List

from . import __version__

PLATFORM_CHOICES = ["tiktok", "youtube", "facebook", "instagram", "douyin"]
PLATFORM_ALIASES = {
    "tt": "tiktok",
    "douyin": "douyin",
    "dy": "douyin",
    "yt": "youtube",
    "youtube": "youtube",
    "fb": "facebook",
    "facebook": "facebook",
    "ig": "instagram",
    "instagram": "instagram",
    "tiktok": "tiktok",
}

_OUTPUT_ARGS: List[Dict[str, Any]] = [
    {
        "name": "format",
        "flag": "--format",
        "type": "string",
        "choices": ["json", "table"],
        "default": "json",
        "description": "Output format. json = machine-readable envelope (default).",
    },
]

COMMANDS: List[Dict[str, Any]] = [
    {
        "name": "status",
        "summary": "Check configuration, credential source, backend reachability and session validity.",
        "read_only": True,
        "usage": "xingqing-cli status [--no-network]",
        "backend": ["GET /api/auth/getCurrentUserInfo"],
        "args": [
            {
                "name": "no_network",
                "flag": "--no-network",
                "type": "boolean",
                "default": False,
                "description": "Skip live backend calls; report local configuration only.",
            },
            *_OUTPUT_ARGS,
        ],
        "returns": "Boolean checks plus account, roles, tenant id and latency.",
    },
    {
        "name": "login",
        "summary": "Authenticate with the 星擎 username/password and cache the session token locally (mode 600).",
        "read_only": False,
        "usage": "xingqing-cli login [--username U] [--password-stdin]",
        "backend": ["POST /api/auth/login"],
        "args": [
            {"name": "username", "flag": "--username", "type": "string", "description": "星擎 account. Falls back to $XINGQING_USERNAME."},
            {
                "name": "password_stdin",
                "flag": "--password-stdin",
                "type": "boolean",
                "default": False,
                "description": "Read the password from stdin instead of prompting (for scripts/agents).",
            },
            {"name": "no_cache", "flag": "--no-cache", "type": "boolean", "default": False, "description": "Validate credentials without writing the local profile."},
            *_OUTPUT_ARGS,
        ],
        "returns": "Account, roles, tenant id, token cache path.",
        "notes": "Prefer $XINGQING_USERNAME/$XINGQING_PASSWORD in agents and CI so nothing is written to disk. Passwords are never accepted as plain CLI flags.",
    },
    {
        "name": "logout",
        "summary": "Invalidate the session server-side and delete the cached token.",
        "read_only": False,
        "usage": "xingqing-cli logout",
        "backend": ["POST /api/auth/logout"],
        "args": [*_OUTPUT_ARGS],
        "returns": "Whether a local profile was removed.",
    },
    {
        "name": "commands",
        "summary": "Self-discovery: list every command with its arguments (no docs required).",
        "read_only": True,
        "usage": "xingqing-cli commands",
        "backend": [],
        "args": [*_OUTPUT_ARGS],
        "returns": "Array of commands: name, summary, usage, read_only, args.",
    },
    {
        "name": "schema",
        "summary": "Self-discovery: JSON schema for every command and its parameters.",
        "read_only": True,
        "usage": "xingqing-cli schema",
        "backend": [],
        "args": [*_OUTPUT_ARGS],
        "returns": "JSON-schema object keyed by command name.",
    },
    {
        "name": "account list",
        "summary": "List social accounts visible to the authenticated tenant (tenant-scoped).",
        "read_only": True,
        "usage": "xingqing-cli account list [--platform tiktok] [--limit N]",
        "backend": ["GET /api/devices/getAccountList", "POST /api/devices/getVideoListPage"],
        "args": [
            {
                "name": "platform",
                "flag": "--platform",
                "type": "string",
                "choices": PLATFORM_CHOICES,
                "description": "Filter accounts by publishing platform. Derived client-side from each account's latest video shareLink (backend exposes no platform attribute) — see meta.platform_source.",
            },
            {"name": "limit", "flag": "--limit", "type": "integer", "default": 0, "description": "Max accounts to return (0 = all)."},
            {"name": "scan_limit", "flag": "--scan-limit", "type": "integer", "default": 200, "description": "Max accounts probed when --platform is used."},
            {"name": "enterprise", "flag": "--enterprise", "type": "string", "description": "Restrict to one enterprise by name or numeric enterpriseId."},
            *_OUTPUT_ARGS,
        ],
        "returns": "Accounts with enterprise, device code and platform when derivable.",
    },
    {
        "name": "account stats",
        "summary": "Per-account performance (videos / plays / likes / comments / shares / country), aggregated client-side.",
        "read_only": True,
        "usage": "xingqing-cli account stats [--account A] [--limit N] [--max-pages N]",
        "backend": ["POST /api/devices/getVideoListPage"],
        "args": [
            {"name": "account", "flag": "--account", "type": "string", "description": "Restrict to one account."},
            {"name": "limit", "flag": "--limit", "type": "integer", "default": 20, "description": "Max account rows (1-200)."},
            {"name": "max_pages", "flag": "--max-pages", "type": "integer", "default": 60, "description": "Page cap for the client-side scan (pageSize 200)."},
            *_OUTPUT_ARGS,
        ],
        "returns": "Per account: videos, plays, likes, comments, shares, country, platform, latestPublishTime, followers (best-effort). meta.partial flags a truncated scan.",
        "notes": "Client-side grouping: the backend exposes tenant-level totals only and has no per-account attribute endpoint. followers is a snapshot from the account's newest video row (backend reports 0 for many rows) — NOT an authoritative account field.",
    },
    {
        "name": "video count",
        "summary": "Aggregated published-video metrics for the authenticated tenant.",
        "read_only": True,
        "usage": "xingqing-cli video count [--enterprise NAME] [--account A] [--platform tiktok]",
        "backend": ["GET /api/devices/getVideoCountInfo", "POST /api/devices/getVideoListPage"],
        "args": [
            {"name": "enterprise", "flag": "--enterprise", "type": "string", "description": "Enterprise name or numeric enterpriseId."},
            {"name": "account", "flag": "--account", "type": "string", "description": "Restrict to one account."},
            {"name": "platform", "flag": "--platform", "type": "string", "choices": PLATFORM_CHOICES, "description": "Exact count for one platform, computed by scanning shareLink domains."},
            {"name": "max_pages", "flag": "--max-pages", "type": "integer", "default": 60, "description": "Page cap for platform scans (pageSize 200)."},
            *_OUTPUT_ARGS,
        ],
        "returns": "Totals: plays, likes, comments, shares, accounts, videos, followers. meta.partial flags a truncated scan.",
    },
    {
        "name": "video list",
        "summary": "List published videos (tenant-scoped), newest first.",
        "read_only": True,
        "usage": "xingqing-cli video list [--enterprise NAME] [--account A] [--platform tiktok] [--country BR] [--sort play] [--limit N] [--page N] [--page-size N] [--no-paginate]",
        "backend": ["POST /api/devices/getVideoListPage"],
        "args": [
            {"name": "enterprise", "flag": "--enterprise", "type": "string", "description": "Enterprise name or numeric enterpriseId."},
            {"name": "account", "flag": "--account", "type": "string", "description": "Restrict to one account."},
            {"name": "platform", "flag": "--platform", "type": "string", "choices": PLATFORM_CHOICES, "description": "Filter by platform, derived from shareLink."},
            {
                "name": "country",
                "flag": "--country",
                "type": "string",
                "description": "Filter by country code, e.g. BR (matches the row's country field). The backend ignores country filters, so the CLI scans pages and filters locally.",
            },
            {
                "name": "sort",
                "flag": "--sort",
                "type": "string",
                "choices": ["play", "like", "comment", "share", "publish"],
                "description": "Sort the scanned rows descending by that metric. Forces a full scan (up to --max-pages) so the top is real, not just the top of the first pages.",
            },
            {"name": "limit", "flag": "--limit", "type": "integer", "default": 20, "description": "Max rows to output (1-5000). The CLI auto-paginates until it has that many (or data runs out)."},
            {"name": "page", "flag": "--page", "type": "integer", "default": None, "description": "Start page (default 1). With --page and no --page-size, the legacy 'page N of --limit rows' shape is kept."},
            {"name": "page_size", "flag": "--page-size", "type": "integer", "default": 200, "description": "Rows requested per backend call (1-200). Does not change the output size, only how many calls are made."},
            {"name": "no_paginate", "flag": "--no-paginate", "type": "boolean", "default": False, "description": "Fetch exactly one page and report next_page instead of auto-paging."},
            {"name": "max_pages", "flag": "--max-pages", "type": "integer", "default": 60, "description": "Page cap for platform scans."},
            {"name": "raw", "flag": "--raw", "type": "boolean", "default": False, "description": "Return untrimmed backend rows instead of the agent-friendly projection."},
            *_OUTPUT_ARGS,
        ],
        "returns": "Videos with metrics, account, enterprise, country, share link.",
        "notes": "Trimmed rows keep the fields an agent needs; raw rows are reachable with --raw. Pagination contract: --limit is the output budget and the CLI auto-paginates in the background (--page-size controls the backend request size); --no-paginate fetches one page only. meta.pagination reports {mode, start_page, page_size, pages_fetched, next_page, total_visible, total_pages, returned, remaining, complete, dedup}; rows are de-duplicated by workId and duplicates are counted. meta.partial=true means data was truncated — never present a partial result as a complete answer. With --country/--sort the CLI scans pages internally (cap --max-pages) and reports meta.scan.",
    },
    {
        "name": "lead list",
        "summary": "List leads (inquiries) visible to the authenticated tenant, newest first.",
        "read_only": True,
        "usage": "xingqing-cli lead list [--page N] [--limit N] [--page-size N] [--no-paginate] [--source S]",
        "backend": ["POST /api/business/selectPage"],
        "args": [
            {"name": "page", "flag": "--page", "type": "integer", "default": 1, "description": "Start page (1-based)."},
            {"name": "limit", "flag": "--limit", "type": "integer", "default": 20, "description": "Max rows to output (1-5000); auto-paginates in the background."},
            {"name": "page_size", "flag": "--page-size", "type": "integer", "default": 200, "description": "Rows requested per backend call (1-200)."},
            {"name": "no_paginate", "flag": "--no-paginate", "type": "boolean", "default": False, "description": "Fetch exactly one page and report next_page."},
            {"name": "source", "flag": "--source", "type": "string", "description": "Filter by lead source code."},
            *_OUTPUT_ARGS,
        ],
        "returns": "Leads with contact / company / phone / country / requirement / source / status.",
    },
    {
        "name": "trend",
        "summary": "Daily trend charts (plays / followers / likes / comments / shares).",
        "read_only": True,
        "usage": "xingqing-cli trend [--start YYYY-MM-DD] [--end YYYY-MM-DD] [--account A]",
        "backend": ["POST /api/devices/searchInfo"],
        "args": [
            {"name": "start", "flag": "--start", "type": "string", "description": "Start date YYYY-MM-DD (default: 6 days ago)."},
            {"name": "end", "flag": "--end", "type": "string", "description": "End date YYYY-MM-DD (default: today)."},
            {"name": "account", "flag": "--account", "type": "string", "description": "Restrict to one account."},
            *_OUTPUT_ARGS,
        ],
        "returns": "Per-day line charts keyed by metric.",
    },
    {
        "name": "hot-video list",
        "summary": "Hot video / hot product discovery lists.",
        "read_only": True,
        "usage": "xingqing-cli hot-video list [--scope client|product] [--page N] [--limit N] [--page-size N] [--no-paginate]",
        "backend": ["POST /api/hotVideo/page/queryPageClientList", "POST /api/hotVideo/page/queryPageHotProductList"],
        "args": [
            {"name": "scope", "flag": "--scope", "type": "string", "choices": ["client", "product"], "default": "client", "description": "client = 客户向, product = 热品榜."},
            {"name": "page", "flag": "--page", "type": "integer", "default": 1, "description": "Start page (1-based)."},
            {"name": "limit", "flag": "--limit", "type": "integer", "default": 20, "description": "Max rows to output (1-5000); auto-paginates in the background."},
            {"name": "page_size", "flag": "--page-size", "type": "integer", "default": 200, "description": "Rows requested per backend call (1-200)."},
            {"name": "no_paginate", "flag": "--no-paginate", "type": "boolean", "default": False, "description": "Fetch exactly one page and report next_page."},
            *_OUTPUT_ARGS,
        ],
        "returns": "Hot videos with author / fans / views / likes / shares.",
    },
    {
        "name": "selfcheck",
        "summary": "One-shot acceptance check: install → auth → discovery → read-only query → tenant isolation.",
        "read_only": True,
        "usage": "xingqing-cli selfcheck",
        "backend": [
            "GET /api/auth/getCurrentUserInfo",
            "GET /api/devices/getAccountList",
            "GET /api/devices/getVideoCountInfo",
            "POST /api/devices/getVideoListPage",
        ],
        "args": [
            {"name": "isolation_probe_ids", "flag": "--isolation-probe-ids", "type": "string", "default": "1,65", "description": "Foreign enterpriseIds used for the cross-tenant probe."},
            *_OUTPUT_ARGS,
        ],
        "returns": "Per-step pass/fail plus an overall verdict; exits non-zero if any step fails.",
    },
]


def commands_payload() -> List[Dict[str, Any]]:
    """Compact catalog for ``commands``."""
    out = []
    for spec in COMMANDS:
        out.append(
            {
                "name": spec["name"],
                "summary": spec["summary"],
                "usage": spec["usage"],
                "read_only": spec["read_only"],
                "args": [arg["flag"] for arg in spec["args"]],
            }
        )
    return out


def _arg_schema(arg: Dict[str, Any]) -> Dict[str, Any]:
    prop: Dict[str, Any] = {
        "type": {"string": "string", "integer": "integer", "boolean": "boolean"}.get(arg["type"], "string"),
        "description": arg["description"],
    }
    if "choices" in arg:
        prop["enum"] = arg["choices"]
    if "default" in arg:
        prop["default"] = arg["default"]
    return prop


def schema_payload() -> Dict[str, Any]:
    """Full parameter schema for ``schema``."""
    commands: Dict[str, Any] = {}
    for spec in COMMANDS:
        commands[spec["name"]] = {
            "summary": spec["summary"],
            "usage": spec["usage"],
            "read_only": spec["read_only"],
            "backend_endpoints": spec["backend"],
            "parameters": {arg["flag"]: _arg_schema(arg) for arg in spec["args"]},
            "returns": spec["returns"],
            **({"notes": spec["notes"]} if "notes" in spec else {}),
        }
    return {
        "cli": "xingqing-cli",
        "version": __version__,
        "output_contract": {
            "stdout": "exactly one JSON envelope: {\"data\":..., \"error\":null, \"meta\":{...}}",
            "formats": ["json", "table", "jsonl"],
            "jsonl": "--format jsonl streams one JSON object per line and ends with a final {\"_meta\":{...}} line (large results).",
            "pagination": "--limit = output budget (CLI auto-paginates), --page-size = backend request size, --no-paginate = single page + next_page; meta.pagination / meta.counts always report total/returned/remaining and dedup.",
            "stderr": "diagnostics only",
            "error_codes": [
                "CONFIG_ERROR",
                "AUTH_REQUIRED",
                "AUTH_FAILED",
                "AUTH_EXPIRED",
                "NETWORK_ERROR",
                "API_ERROR",
                "NOT_FOUND",
                "INVALID_ARG",
                "UNSUPPORTED",
                "INTERNAL_ERROR",
            ],
            "exit_codes": {"ok": 0, "error": 1, "usage": 2},
        },
        "commands": commands,
    }


def dump_schema_json() -> str:
    return json.dumps(schema_payload(), ensure_ascii=False, indent=2)
