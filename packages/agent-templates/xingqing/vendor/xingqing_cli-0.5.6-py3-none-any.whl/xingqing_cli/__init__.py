"""xingqing-cli — Agent-first CLI for read-only 星擎 (Xingqing) data queries.

Thin client over the existing 星擎 backend REST API (https://xingqing.ultronx.tech).
No business logic is re-implemented here: tenant scoping, aggregation and
enterprise mapping stay on the server.
"""

__version__ = "0.5.6"

__all__ = ["__version__"]
