"""Command implementations.

Design rule: this layer only shapes requests and formats responses. Tenant
scoping, aggregation and enterprise mapping remain server-side.
"""

from __future__ import annotations

import getpass
import os
import sys
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional, Tuple

from . import __version__, credentials, registry
from .client import Client
from .errors import AUTH_REQUIRED, INVALID_ARG, NOT_FOUND, UNSUPPORTED, CliError

SCAN_PAGE_SIZE = 200
# Hard ceiling for one command's output. Auto-pagination fetches as many
# backend pages as needed, but never more than this many rows per invocation.
MAX_LIMIT = 5000


def _page_size_of(args: Any) -> int:
    """Backend page size (how much we ask for per request)."""
    raw = getattr(args, "page_size", None)
    value = SCAN_PAGE_SIZE if raw is None else int(raw)
    if value < 1 or value > SCAN_PAGE_SIZE:
        raise CliError(INVALID_ARG, f"--page-size 必须在 1..{SCAN_PAGE_SIZE} 之间")
    return value


def _limit_of(args: Any, default: int = 20) -> int:
    """Output row budget for this invocation (auto-pagination may span pages).

    An explicitly passed ``--limit 0`` is out of contract and must be refused;
    only an omitted flag falls back to ``default``.
    """
    raw = getattr(args, "limit", None)
    value = default if raw is None else int(raw)
    if value < 1 or value > MAX_LIMIT:
        raise CliError(INVALID_ARG, f"--limit 必须在 1..{MAX_LIMIT} 之间")
    return value


def _no_paginate(args: Any) -> bool:
    return bool(getattr(args, "no_paginate", False))


def _pagination_meta(
    start_page: int,
    page_size: int,
    pages_fetched: int,
    next_page: Optional[int],
    exhausted: bool,
    total_visible: Optional[int],
    total_pages: Optional[int],
    returned: int,
    duplicates: int,
    mode: str,
) -> Dict[str, Any]:
    remaining = None
    if isinstance(total_visible, int):
        consumed_before = (start_page - 1) * page_size
        remaining = max(0, total_visible - consumed_before - returned)
    return {
        "mode": mode,  # auto | single_page | full_scan
        "start_page": start_page,
        "page_size": page_size,
        "pages_fetched": pages_fetched,
        "next_page": next_page,
        "total_visible": total_visible,
        "total_pages": total_pages,
        "returned": returned,
        "remaining": remaining,
        "complete": bool(exhausted),
        "dedup": {"by": "workId", "duplicates_removed": duplicates},
    }


# --------------------------------------------------------------------------
# session resolution
# --------------------------------------------------------------------------


class Session:
    """Authentication context for one CLI invocation."""

    def __init__(
        self,
        base_url: str,
        token: Optional[str],
        account: Optional[str] = None,
        roles: Optional[List[str]] = None,
        tenant_id: Optional[int] = None,
        nick_name: Optional[str] = None,
        source: str = "none",
    ) -> None:
        self.base_url = base_url
        self.token = token
        self.account = account
        self.roles = roles or []
        self.tenant_id = tenant_id
        self.nick_name = nick_name
        self.source = source

    @property
    def is_admin(self) -> bool:
        """manager/operator are cross-tenant by design; client is tenant-scoped."""
        return any(role in ("manager", "operator") for role in self.roles)

    def client(self) -> Client:
        return Client(self.base_url, token=self.token)

    def describe(self) -> Dict[str, Any]:
        return {
            "base_url": self.base_url,
            "credential_source": self.source,
            "account": self.account,
            "roles": self.roles,
            "tenant_id": self.tenant_id,
            "enterprise": self.nick_name,
            "role_scope": "cross_tenant" if self.is_admin else "tenant",
        }


def _identity_from_login(result: Dict[str, Any]) -> Tuple[Optional[str], List[str], Optional[int], Optional[str]]:
    user = result.get("userInfo") or {}
    return (
        user.get("account"),
        list(result.get("roles") or []),
        user.get("id"),
        user.get("nickName"),
    )


def resolve_session(base_url: str, allow_env_login: bool = True, allow_profile: bool = True) -> Session:
    """Resolve credentials: env (in-memory login) → cached profile → none."""
    env = credentials.env_credentials()
    if env and allow_env_login:
        username, password = env
        client = Client(base_url)
        result = client.login(username, password)
        account, roles, tenant_id, nick = _identity_from_login(result)
        return Session(
            base_url=base_url,
            token=result["token"],
            account=account or username,
            roles=roles,
            tenant_id=tenant_id,
            nick_name=nick,
            source="env",
        )

    profile = credentials.load_profile()
    token = profile.get("token")
    if token and not allow_profile:
        # 未绑定企业状态：不允许回退到本机缓存的登录身份（那可能是别家企业的）。
        raise CliError(
            AUTH_REQUIRED,
            "尚未绑定企业：现在没有属于你的访问凭证。",
            details={"credential_source": "profile_ignored", "profile_account": profile.get("account")},
            hint="请提供你企业的星擎账号（账号 + 密码）作为身份，我确认后才能查你的数据。",
        )
    if token:
        return Session(
            base_url=base_url,
            token=token,
            account=profile.get("account"),
            roles=list(profile.get("roles") or []),
            tenant_id=profile.get("tenant_id"),
            nick_name=profile.get("enterprise"),
            source="profile",
        )

    return Session(base_url=base_url, token=None, source="none")


def require_auth(session: Session) -> Session:
    if session.token:
        return session
    raise CliError(
        AUTH_REQUIRED,
        "未登录：没有可用的会话凭证",
        details={"credential_source": session.source},
        hint="运行 `xingqing-cli login`，或设置 XINGQING_USERNAME/XINGQING_PASSWORD。",
    )


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------


def normalize_platform(value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    key = value.strip().lower()
    resolved = registry.PLATFORM_ALIASES.get(key)
    if not resolved:
        raise CliError(
            INVALID_ARG,
            f"不支持的 platform: {value}",
            details={"supported": sorted(set(registry.PLATFORM_ALIASES.values()))},
        )
    return resolved


def platform_from_link(link: Optional[str]) -> Optional[str]:
    """Derive the publishing platform from a video share link.

    The backend exposes no platform column for accounts/videos, so the only
    authoritative platform evidence is the share link domain.
    """
    if not link or not isinstance(link, str):
        return None
    host = link.split("://")[-1].split("/")[0].lower()
    host = host.split("@")[-1].split(":")[0]
    if "tiktok" in host:
        return "tiktok"
    if "youtube" in host or "youtu.be" in host:
        return "youtube"
    if "facebook" in host or "fb.watch" in host:
        return "facebook"
    if "instagram" in host:
        return "instagram"
    if "douyin" in host:
        return "douyin"
    if "xiaohongshu" in host or "xhslink" in host:
        return "xiaohongshu"
    return "unknown"


VIDEO_FIELDS = (
    "id",
    "workId",
    "accId",
    "title",
    "account",
    "accountGroup",
    "enterpriseId",
    "country",
    "playCount",
    "likeCount",
    "commentCount",
    "shareCount",
    "followerCount",
    "publishTime",
    "shareLink",
    "coverUrl",
)


def trim_video(row: Dict[str, Any]) -> Dict[str, Any]:
    out = {key: row.get(key) for key in VIDEO_FIELDS if key in row}
    out["platform"] = platform_from_link(row.get("shareLink"))
    if out.get("publishTime"):
        out["publishTimeIso"] = datetime.fromtimestamp(
            out["publishTime"] / 1000, tz=timezone.utc
        ).isoformat()
    title = out.get("title")
    if isinstance(title, str) and len(title) > 160:
        out["title"] = title[:157] + "..."
    return out


def iter_videos(
    client: Client,
    enterprise_id: Optional[int] = None,
    account: Optional[str] = None,
    max_pages: int = 60,
    page_size: int = SCAN_PAGE_SIZE,
) -> Iterable[Dict[str, Any]]:
    """Stream videos page by page (server-side filters applied)."""
    page = 1
    while page <= max_pages:
        result = client.video_list_page(
            page_no=page,
            page_size=page_size,
            enterprise_id=enterprise_id,
            account=account,
        )
        rows = result.get("list") or []
        for row in rows:
            if isinstance(row, dict):
                yield row
        if len(rows) < page_size:
            return
        page += 1


def _video_key(row: Dict[str, Any]) -> str:
    """Video identity: shareLink video id wins, otherwise workId.

    同一支视频在明细里可能出现多行（workId 不同、shareLink 相同）。
    康浩源 2026-09-21：「share link 相同就算一条」。
    """
    link = row.get("shareLink") or ""
    if isinstance(link, str) and "/video/" in link:
        vid = link.split("/video/")[-1].split("?")[0].strip("/")
        if vid:
            return "link:" + vid
    return "work:" + str(row.get("workId"))


def _reject_cross_tenant(session: "Session") -> None:
    """客户数据只能用客户企业身份查。

    康浩源 2026-09-21：admin（manager/operator，跨租户）不允许登录查看；
    没有跨企业需求，所以跨租户凭证一律拒绝。
    """
    if session.is_admin:
        raise CliError(
            UNSUPPORTED,
            "当前凭证是平台管理员（跨租户）身份，不允许用于客户数据查询。",
            details={"roles": session.roles, "account": session.account},
            hint="请改用该客户企业自己的账号（client 角色）。",
        )


def _own_enterprise_ids(client: Client, max_pages: int = 5) -> set:
    """Enterprise ids actually visible to the CURRENT session (from its own videos).

    Non-admin sessions are tenant-scoped. The login response only carries a
    user id (not the enterpriseId), so visibility is derived from the rows the
    session can actually read.
    """
    ids = set()
    page = 1
    while page <= max_pages:
        result = client.video_list_page(page_no=page, page_size=SCAN_PAGE_SIZE)
        rows = [r for r in (result.get("list") or []) if isinstance(r, dict)]
        for row in rows:
            if row.get("enterpriseId") is not None:
                ids.add(row["enterpriseId"])
        if len(rows) < SCAN_PAGE_SIZE:
            break
        page += 1
    return ids


def resolve_enterprise(
    client: Client,
    session: Session,
    value: Optional[str],
    max_pages: int = 5,
) -> Tuple[Optional[str], Optional[int], Optional[str]]:
    """Resolve ``--enterprise`` (name or id) to a server filter.

    Returns ``(kind, enterprise_id, note)``. Crucially, an enterprise that is
    NOT in the caller's visible scope is REJECTED loudly (``NOT_FOUND``) — the
    CLI must never send an ineffective filter and then echo it back, because
    the server would return the caller's OWN data and the agent would report
    it as another enterprise's data.

    Non-admin sessions are tenant-scoped; admin (manager/operator) sessions are
    cross-tenant by design.
    """
    if not value:
        return None, None, None
    value = value.strip()

    if value.isdigit():
        target = int(value)
        if not session.is_admin:
            own = _own_enterprise_ids(client)
            if target not in own:
                raise CliError(
                    NOT_FOUND,
                    f"企业 id={target} 不在当前账号可见范围。",
                    details={
                        "requested_enterprise_id": target,
                        "visible_enterprise_ids": sorted(x for x in own if x is not None),
                    },
                    hint="非管理员账号只能查询本企业数据；跨企业查询请用管理员账号。",
                )
        return "id", target, None

    # name -> id, searched only within rows this session can see
    matched: Optional[int] = None
    for row in iter_videos(client, max_pages=max_pages):
        group = (row.get("accountGroup") or "").strip()
        ent_id = row.get("enterpriseId")
        if group and (group == value or value in group):
            matched = ent_id
            break
    if matched is None:
        if session.nick_name and value in session.nick_name:
            return None, None, f"enterprise 匹配当前租户「{session.nick_name}」，无额外过滤。"
        if session.is_admin:
            raise CliError(
                NOT_FOUND,
                f"未找到企业「{value}」",
                details={"searched_scope": "visible_videos", "max_pages": max_pages, "partial": True},
                hint="企业名解析为轻量扫描（有页数上限），可能存在更深页未扫到；可用企业 id 精确指定。",
            )
        raise CliError(
            NOT_FOUND,
            f"企业「{value}」不在当前账号可见范围。",
            details={"searched_scope": "visible_videos", "max_pages": max_pages, "partial": True},
            hint="非管理员账号只能查询本企业数据；跨企业查询请用管理员账号。",
        )
    return "name", matched, f"enterprise「{value}」→ enterpriseId={matched}"


def _enterprise_filter(
    session: Session, kind: Optional[str], enterprise_id: Optional[int]
) -> Optional[int]:
    """Only send an enterpriseId the caller is allowed to ask for."""
    if kind is None:
        return None
    if kind == "id" and enterprise_id == -1:
        return -1  # sentinel: caller asked for a foreign/unmatched enterprise
    return enterprise_id


# --------------------------------------------------------------------------
# commands
# --------------------------------------------------------------------------


def cmd_status(args: Any, base_url: str) -> Dict[str, Any]:
    import time

    started = time.monotonic()
    checks: Dict[str, Any] = {}
    session = resolve_session(base_url)
    checks["config"] = {
        "base_url": base_url,
        "credential_source": session.source,
        "credentials_path": str(credentials.credentials_path()),
        "env_credentials_present": credentials.env_credentials() is not None,
    }

    data: Dict[str, Any] = {
        "service": base_url,
        "version": __version__,
        "reachable": None,
        "latency_ms": None,
        "auth": {"ok": False, "reason": "no_credentials"},
        "identity": None,
    }

    if args.no_network:
        data["reachable"] = "skipped"
        data["auth"] = {"ok": bool(session.token), "reason": "not_checked"}
        return {"checks": checks, **data}

    client = session.client()
    try:
        info = client.get_current_user()
        reachable = True
    except CliError as exc:
        reachable = exc.code != "NETWORK_ERROR"
        info = None
        data["error_detail"] = exc.to_dict()
    data["latency_ms"] = round((time.monotonic() - started) * 1000, 1)
    data["reachable"] = reachable

    if not reachable:
        return {"checks": checks, **data}

    if info and info.get("userInfo"):
        user = info["userInfo"]
        data["auth"] = {"ok": True, "reason": "session_valid"}
        data["identity"] = {
            "account": user.get("account"),
            "enterprise": user.get("nickName"),
            "tenant_id": user.get("id"),
            "roles": list(info.get("roles") or []),
            "role_scope": "cross_tenant"
            if any(r in ("manager", "operator") for r in (info.get("roles") or []))
            else "tenant",
        }
    elif session.token:
        data["auth"] = {"ok": False, "reason": "token_rejected"}
    else:
        data["auth"] = {"ok": False, "reason": "no_credentials"}
    return {"checks": checks, **data}


def cmd_login(args: Any, base_url: str) -> Dict[str, Any]:
    username = args.username or os.environ.get(credentials.ENV_USERNAME)
    password: Optional[str] = None
    password_source: Optional[str] = None

    # An explicitly supplied password always wins over env credentials.
    # (Previously env XINGQING_PASSWORD silently overrode --password-stdin,
    # causing a false-positive "login succeeded" with the wrong password.)
    if args.password_stdin:
        password = sys.stdin.readline().rstrip("\n")
        if not password:
            raise CliError(INVALID_ARG, "--password-stdin 未读到内容")
        password_source = "stdin"
    elif sys.stdin.isatty():
        if not username:
            raise CliError(INVALID_ARG, "缺少用户名", hint="用 --username 传入，或设置 XINGQING_USERNAME。")
        password = getpass.getpass(f"星擎密码（{username}）: ")
        password_source = "prompt"
    else:
        env = credentials.env_credentials()
        if env and (not username or env[0] == username):
            username, password = env
            password_source = "env"

    if not username:
        profile = credentials.load_profile()
        username = profile.get("account")
    if not username:
        raise CliError(INVALID_ARG, "缺少用户名", hint="用 --username 传入，或设置 XINGQING_USERNAME。")
    if password is None:
        raise CliError(
            INVALID_ARG,
            "无可用密码来源",
            hint="使用 --password-stdin、设置 XINGQING_PASSWORD，或在交互终端中登录。",
        )

    client = Client(base_url)
    result = client.login(username, password)
    account, roles, tenant_id, nick = _identity_from_login(result)

    cached = False
    profile_path = None
    if not args.no_cache:
        path = credentials.save_profile(
            {
                "base_url": base_url,
                "account": account or username,
                "enterprise": nick,
                "roles": roles,
                "tenant_id": tenant_id,
                "token": result["token"],
                "saved_at": datetime.now(timezone.utc).isoformat(),
            }
        )
        cached = True
        profile_path = str(path)

    return {
        "account": account or username,
        "enterprise": nick,
        "roles": roles,
        "tenant_id": tenant_id,
        "role_scope": "cross_tenant" if any(r in ("manager", "operator") for r in roles) else "tenant",
        "token_cached": cached,
        "profile_path": profile_path,
        "password_source": password_source,
    }


def cmd_logout(args: Any, base_url: str) -> Dict[str, Any]:
    session = resolve_session(base_url, allow_env_login=False)
    server_ok = False
    if session.token:
        try:
            Client(base_url, token=session.token).logout()
            server_ok = True
        except CliError:
            server_ok = False
    removed = credentials.clear_profile()
    return {"server_logout": server_ok, "local_profile_removed": removed}


def cmd_commands(args: Any, base_url: str) -> Dict[str, Any]:
    return {"commands": registry.commands_payload()}


def cmd_schema(args: Any, base_url: str) -> Dict[str, Any]:
    payload = registry.schema_payload()
    raw = getattr(args, "command_name", None) or []
    if isinstance(raw, str):
        raw = [raw]
    # Accept `schema video list`, `schema "video list"` and `schema video` (unique prefix).
    target = " ".join(raw).strip()
    if target:
        commands = payload.get("commands", {})
        if target not in commands:
            matches = [name for name in commands if name.startswith(target)]
            if len(matches) == 1:
                target = matches[0]
            elif matches:
                raise CliError(INVALID_ARG, f"命令名不明确: {target}", details={"candidates": sorted(matches)})
            else:
                raise CliError(INVALID_ARG, f"未知命令: {target}", details={"available": sorted(commands)})
        return {
            "cli": payload.get("cli"),
            "version": payload.get("version"),
            "command": target,
            "schema": commands[target],
        }
    return payload


def _identity_meta(session: Session) -> Dict[str, Any]:
    """Fields the schema promises on every authenticated command."""
    return {"base_url": session.base_url, "account": session.account, "source": session.source}


def _require_visible_account(client: Client, account: Optional[str]) -> None:
    """An account outside the caller's visible set is REJECTED loudly.

    Mirrors the enterprise rule: never accept a filter the server will ignore,
    because the caller would get its OWN data back and think it asked for
    someone else's.
    """
    if not account:
        return
    visible = set(client.account_list())
    if account not in visible:
        raise CliError(
            NOT_FOUND,
            f"账号「{account}」不在当前账号可见范围。",
            details={"account": account, "visible_accounts": len(visible)},
            hint="检查账号名是否正确，或该账号是否属于当前租户。",
        )


def cmd_account_list(args: Any, base_url: str) -> Dict[str, Any]:
    session = require_auth(resolve_session(base_url, allow_profile=False))
    _reject_cross_tenant(session)
    client = session.client()
    platform = normalize_platform(args.platform)

    kind, enterprise_id, note = resolve_enterprise(client, session, args.enterprise)
    meta: Dict[str, Any] = _identity_meta(session)
    if note:
        meta["enterprise_note"] = note

    if kind == "id" and enterprise_id == -1:
        return {"items": [], "total": 0}, meta

    filter_id = _enterprise_filter(session, kind, enterprise_id)

    accounts = client.account_list()
    if not isinstance(accounts, list):
        accounts = []

    enrolled: Dict[str, Dict[str, Any]] = {}
    if filter_id is not None and filter_id != -1:
        meta["enrichment"] = "enterprise_filtered"
        for row in iter_videos(client, enterprise_id=filter_id, max_pages=30):
            acc = row.get("account")
            if acc and acc not in enrolled:
                enrolled[acc] = {
                    "account": acc,
                    "enterpriseId": row.get("enterpriseId"),
                    "enterprise": row.get("accountGroup"),
                    "platform": platform_from_link(row.get("shareLink")),
                }
        accounts = sorted(enrolled)
        candidates = list(enrolled.values())
    else:
        candidates = [{"account": acc} for acc in accounts]

    if platform:
        scan_limit = max(1, int(args.scan_limit))
        meta["platform_source"] = "derived_from_shareLink"
        meta["platform_scan"] = {"requested": len(candidates), "scanned": 0, "limit": scan_limit}
        targets = candidates[:scan_limit]
        meta["platform_scan"]["truncated"] = len(candidates) > scan_limit

        def probe(item: Dict[str, Any]) -> Dict[str, Any]:
            acc = item["account"]
            try:
                page = client.video_list_page(page_no=1, page_size=1, account=acc)
                rows = page.get("list") or []
                link = rows[0].get("shareLink") if rows else None
                item = dict(item)
                item["platform"] = platform_from_link(link)
                item["enterpriseId"] = item.get("enterpriseId") or (rows[0].get("enterpriseId") if rows else None)
                item["enterprise"] = item.get("enterprise") or (rows[0].get("accountGroup") if rows else None)
                return item
            except CliError as exc:
                item = dict(item)
                item["platform"] = None
                item["platform_error"] = exc.code
                return item

        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(probe, targets))
        meta["platform_scan"]["scanned"] = len(results)
        meta["platform_scan"]["unknown"] = sum(1 for r in results if not r.get("platform"))
        items = [r for r in results if r.get("platform") == platform]
    else:
        items = [dict(c) for c in candidates]

    total_matched = len(items)
    if args.limit and args.limit > 0:
        meta["limit"] = args.limit
        items = items[: args.limit]

    return {
        "items": items,
        # `total` = matching count BEFORE --limit (the true answer to "how many"),
        # `returned` = rows actually returned after --limit. Never let a page
        # size masquerade as a tenant total.
        "total": total_matched,
        "returned": len(items),
        "filters": {"platform": platform, "enterprise": args.enterprise},
    }, meta


def cmd_account_stats(args: Any, base_url: str) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Per-account performance, aggregated client-side from the caller's videos.

    The backend has no per-account attribute endpoint: ``getAccountList`` returns
    bare handles and ``getVideoCountInfo`` returns tenant-level totals only. So
    account-level metrics are derived here by scanning the caller's own video
    rows once and grouping them by ``account`` (server-side tenant scoping still
    applies — the CLI never widens the caller's scope).

    ``followers`` is NOT an authoritative account field: it is the
    ``followerCount`` snapshot carried on the account's newest video row, and the
    backend reports 0 for many rows. Treat it as a floor, never as the real
    follower count. Per-account followers still need a backend field (option A).
    """
    session = require_auth(resolve_session(base_url, allow_profile=False))
    _reject_cross_tenant(session)
    client = session.client()

    limit = int(args.limit if args.limit is not None else 20)
    if limit < 1 or limit > SCAN_PAGE_SIZE:
        raise CliError(INVALID_ARG, f"--limit 必须在 1..{SCAN_PAGE_SIZE} 之间")
    max_pages = int(args.max_pages or 60)
    if max_pages < 1:
        raise CliError(INVALID_ARG, "--max-pages 必须 >= 1")

    _require_visible_account(client, args.account)

    agg: Dict[str, Dict[str, Any]] = {}
    scanned = 0
    pages = 0
    exhausted = True
    page = 1
    while page <= max_pages:
        result = client.video_list_page(
            page_no=page, page_size=SCAN_PAGE_SIZE, account=args.account or None
        )
        rows = [r for r in (result.get("list") or []) if isinstance(r, dict)]
        pages += 1
        if not rows:
            break
        for row in rows:
            scanned += 1
            acc = row.get("account")
            if not acc:
                continue
            item = agg.get(acc)
            if item is None:
                item = {
                    "account": acc,
                    "enterprise": row.get("accountGroup"),
                    "enterpriseId": row.get("enterpriseId"),
                    "platform": None,
                    "country": row.get("country"),
                    "videos": 0,
                    "plays": 0,
                    "likes": 0,
                    "comments": 0,
                    "shares": 0,
                    "followers": None,
                    "latestPublishTime": None,
                }
                agg[acc] = item
            item["videos"] += 1
            item["plays"] += int(row.get("playCount") or 0)
            item["likes"] += int(row.get("likeCount") or 0)
            item["comments"] += int(row.get("commentCount") or 0)
            item["shares"] += int(row.get("shareCount") or 0)
            if not item["country"] and row.get("country"):
                item["country"] = row.get("country")
            if not item["platform"]:
                item["platform"] = platform_from_link(row.get("shareLink"))
            publish_time = row.get("publishTime")
            latest = item["latestPublishTime"]
            if publish_time is not None and (latest is None or publish_time > latest):
                item["latestPublishTime"] = publish_time
                follower_count = row.get("followerCount")
                if follower_count:
                    item["followers"] = follower_count
        if len(rows) < SCAN_PAGE_SIZE:
            break
        page += 1
    else:
        exhausted = False

    ordered = sorted(agg.values(), key=lambda x: x["plays"], reverse=True)
    accounts_total = len(ordered)
    items = ordered[:limit]
    remaining = max(0, accounts_total - len(items))
    reasons = []
    if not exhausted:
        reasons.append("scan_hit_max_pages")
    if remaining > 0:
        reasons.append(f"rows_truncated_by_limit({accounts_total}>{limit})")
    meta: Dict[str, Any] = {
        "scanned_videos": scanned,
        "pages": pages,
        "accounts_seen": accounts_total,
        "accounts_total": accounts_total,
        "returned": len(items),
        "remaining": remaining,
        "counts": {"accounts_total": accounts_total, "returned": len(items), "remaining": remaining},
        "partial": (not exhausted) or remaining > 0,
        "partial_reasons": reasons,
        "aggregation": "client-side grouping of /api/devices/getVideoListPage rows",
        "followers_caveat": "snapshot from the account's newest video row; backend reports 0 for many rows — not an authoritative account field",
        **_identity_meta(session),
    }
    if args.account:
        meta["account_filter"] = args.account
    return {
        "items": items,
        "accounts_total": accounts_total,
        "returned": len(items),
        "remaining": remaining,
        "filters": {"account": args.account},
        "aggregation": "ranking_only",
        "note": (
            "口径：**只用于账号间对比（排序）**，不是总量口径、不可与总量相加（康浩源 2026-09-21：明细口径不对、不对外）。"
            "**这不是客户可见的总量口径**——总量以 `video count`（服务端聚合）为准，两者实测不一致，不可互证；"
            "本命令 partial=false 时才是完整扫描结果。"
        ),
    }, meta


def _scan_aggregate(
    client: Client,
    enterprise_id: Optional[int],
    account: Optional[str],
    platform: Optional[str],
    max_pages: int,
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    totals = {
        "videoCount": 0,
        "allPlayCount": 0,
        "allLikeCount": 0,
        "allCommentCount": 0,
        "allShareCount": 0,
    }
    accounts: set = set()
    scanned = 0
    exhausted = True
    page = 1
    while page <= max_pages:
        result = client.video_list_page(
            page_no=page,
            page_size=SCAN_PAGE_SIZE,
            enterprise_id=enterprise_id,
            account=account,
        )
        rows = [r for r in (result.get("list") or []) if isinstance(r, dict)]
        for row in rows:
            scanned += 1
            if platform and platform_from_link(row.get("shareLink")) != platform:
                continue
            totals["videoCount"] += 1
            totals["allPlayCount"] += int(row.get("playCount") or 0)
            totals["allLikeCount"] += int(row.get("likeCount") or 0)
            totals["allCommentCount"] += int(row.get("commentCount") or 0)
            totals["allShareCount"] += int(row.get("shareCount") or 0)
            if row.get("account"):
                accounts.add(row["account"])
        if len(rows) < SCAN_PAGE_SIZE:
            break
        page += 1
    else:
        exhausted = False
    totals["allAccountCount"] = len(accounts)
    meta = {
        "aggregation": "client_side_scan",
        "scanned_rows": scanned,
        "exhaustive": exhausted,
        "partial": not exhausted,
        "platform_source": "derived_from_shareLink" if platform else None,
    }
    return totals, meta


def cmd_video_count(args: Any, base_url: str) -> Dict[str, Any]:
    session = require_auth(resolve_session(base_url, allow_profile=False))
    _reject_cross_tenant(session)
    client = session.client()
    platform = normalize_platform(args.platform)
    kind, enterprise_id, note = resolve_enterprise(client, session, args.enterprise)
    meta: Dict[str, Any] = _identity_meta(session)
    if note:
        meta["enterprise_note"] = note
    if kind == "id" and enterprise_id == -1:
        return {"totals": {}, "filters": {}}, meta

    filter_id = _enterprise_filter(session, kind, enterprise_id)
    filters = {"enterprise": args.enterprise, "account": args.account, "platform": platform}
    _require_visible_account(client, args.account)

    if filter_id is None and not args.account and not platform:
        totals = client.video_count_info()
        meta["aggregation"] = "server"
        meta["aggregation_path"] = "server_aggregate(/api/devices/getVideoCountInfo)"
        meta["field_notes"] = {
            "clueCount": (
                "来自后端聚合接口；实测与 lead list 的总数不一致（0 vs 171），口径未确认。"
                "查线索请用 lead list，不要用这个字段。"
            ),
            "allAccountCount": (
                "后端聚合口径，可能小于 account list 的账号数（实测 178 vs 240）；要账号清单请用 account list。"
            ),
        }
        meta["cross_path_warning"] = (
            "无筛选时走服务端聚合，带 --enterprise/--account/--platform 时走明细扫描，两条路的数字实测不一致；"
            "同一轮比较只能用同一条路。"
        )
        return {
            "totals": totals,
            "filters": filters,
            "aggregation": "server_aggregate",
            "note": (
                "口径：服务端聚合统计（/api/devices/getVideoCountInfo）——**这就是星擎后台客户可见的口径**"
                "（2026-09-21 用客户后台数字逐项核对：播放/点赞/评论/粉丝/已发布视频/线索 6/6 精确一致）。"
                "同租户另有一条【明细口径】（CLI 扫描逐行求和）数值偏高，只用于看单条视频/单账号表现，"
                "不可当总量、不可与本口径相加。"
            ),
            "field_notes": meta.get("field_notes"),
        }, meta

    raise CliError(
        UNSUPPORTED,
        "总量不支持按企业/账号/平台筛选：对外只有唯一口径「不带筛选的服务端聚合」。",
        details={"enterprise": args.enterprise, "account": args.account, "platform": platform},
        hint="要看某个账号的表现，用 `account stats`（账号间对比，不是总量口径）。",
    )

    totals, scan_meta = _scan_aggregate(client, filter_id, args.account, platform, int(args.max_pages))
    meta.update(scan_meta)
    meta["aggregation_path"] = "client_scan(detail rows of /api/devices/getVideoListPage)"
    meta["note"] = "带 --enterprise/--account/--platform 的统计由 CLI 扫描明细得出（后端无对应聚合接口）。"
    meta["cross_path_warning"] = (
        "本结果来自明细扫描；无筛选时 CLI 走服务端聚合，两条路实测数字不一致，不要混用。"
    )
    meta["field_notes"] = {"clueCount": "明细扫描路径不产出线索数（该字段仅服务端聚合路径存在）。"}
    return {
        "totals": totals,
        "filters": filters,
        "aggregation": "client_scan",
        "note": (
            "口径：CLI 扫描明细逐行求和（/api/devices/getVideoListPage）。不筛选时的【服务端聚合口径】"
            "实测与本口径不一致（账号数、播放/点赞/评论/分享均偏低），两条不可相加、不可互相印证。"
        ),
    }, meta


def cmd_video_list(args: Any, base_url: str) -> Dict[str, Any]:
    session = require_auth(resolve_session(base_url, allow_profile=False))
    _reject_cross_tenant(session)
    client = session.client()
    platform = normalize_platform(args.platform)
    limit = _limit_of(args, 20)
    page_size = _page_size_of(args)
    no_paginate = _no_paginate(args)
    explicit_page = getattr(args, "page", None) is not None
    # --country / --sort exist because the backend ignores those filters: we must scan.
    country = (args.country or "").strip().upper() or None
    if country and not (2 <= len(country) <= 3):
        raise CliError(
            INVALID_ARG,
            "--country 需要两位国家码，例如 BR（明细行的 country 字段值）。",
            details={"country": args.country},
        )
    sort_choice = args.sort
    sort_field = {
        "play": "playCount",
        "like": "likeCount",
        "comment": "commentCount",
        "share": "shareCount",
        "publish": "publishTime",
    }.get(sort_choice or "")
    scan_mode = bool(platform or country or sort_field)
    # --page with a scan filter is ambiguous (a scan is not a page walk): refuse it.
    # Plain listing treats --page as the START page and auto-paginates from there.
    if scan_mode and int(args.page or 1) != 1:
        # A scan is not a page walk: --page has no meaning with any scan filter
        # (--sort / --platform / --country). Refuse instead of guessing.
        offender = "--sort" if sort_field else ("--platform" if platform else "--country")
        raise CliError(
            INVALID_ARG,
            f"--page 不能与 {offender} 同时使用：该条件需要全量扫描，没有“第 N 页”的概念。",
            details={"page": int(args.page or 1), "conflict": offender, "sort": sort_choice},
            hint="去掉 --page；或用 --limit 控制返回行数。",
        )
    if explicit_page and not getattr(args, "page_size", None):
        # Backwards compatible: explicit --page keeps the old "page N of --limit rows" shape.
        page_size = limit

    kind, enterprise_id, note = resolve_enterprise(client, session, args.enterprise)
    meta: Dict[str, Any] = {"total_visible": None, **_identity_meta(session)}
    if note:
        meta["enterprise_note"] = note
    if kind == "id" and enterprise_id == -1:
        return {"items": [], "returned": 0, "filters": {}}, meta

    filter_id = _enterprise_filter(session, kind, enterprise_id)
    filters = {
        "enterprise": args.enterprise,
        "account": args.account,
        "platform": platform,
        "country": country,
        "sort": sort_choice,
    }
    _require_visible_account(client, args.account)

    if not scan_mode:
        start_page = int(args.page or 1)
        rows: List[Dict[str, Any]] = []
        seen: set = set()
        duplicates = 0
        page_no = start_page
        pages_fetched = 0
        exhausted = False
        out_of_range = False
        total_visible: Optional[int] = None
        total_pages: Optional[int] = None
        while True:
            page = client.video_list_page(
                page_no=page_no,
                page_size=page_size,
                enterprise_id=filter_id,
                account=args.account,
            )
            pages_fetched += 1
            total_visible = page.get("total") if page.get("total") is not None else total_visible
            total_pages = int(page.get("pages") or 0) or total_pages
            if total_pages and page_no > total_pages:
                # The backend silently repeats the last page for out-of-range
                # pages; never pass that off as page N.
                out_of_range = True
                break
            batch = [r for r in (page.get("list") or []) if isinstance(r, dict)]
            for row in batch:
                key = _video_key(row)
                if key in seen:
                    duplicates += 1
                    continue
                seen.add(key)
                rows.append(row)
            if len(batch) < page_size or not batch:
                exhausted = True
                break
            if len(rows) >= limit or no_paginate:
                break
            page_no += 1

        selected = rows[:limit]
        if no_paginate and len(rows) > limit:
            # single page was bigger than the output budget: the rest is still there
            pass
        next_page = page_no + 1 if (not exhausted and not out_of_range and not no_paginate) else None
        if no_paginate and not exhausted and not out_of_range:
            next_page = page_no + 1
        items = selected if args.raw else [trim_video(r) for r in selected]
        mode = "single_page" if no_paginate else "auto"
        pagination = _pagination_meta(
            start_page, page_size, pages_fetched, next_page, exhausted,
            total_visible, total_pages, len(items), duplicates, mode,
        )
        meta.update(
            {
                "page": start_page,
                "page_size": page_size,
                "pages": total_pages,
                "total_visible": total_visible,
                "next_page": next_page,
                "counts": {
                    "total": total_visible,
                    "returned": len(items),
                    "remaining": pagination.get("remaining"),
                    "pages": total_pages,
                },
                "pagination": pagination,
                "partial": bool(next_page is not None or out_of_range),
            }
        )
        if out_of_range:
            meta["out_of_range"] = True
            meta["note"] = (
                f"请求第 {start_page} 页，但本次范围只有 {total_pages} 页；"
                "后端会重复返回末页，CLI 返回空并标记 out_of_range，避免把重复行当成新数据。"
            )
            return {"items": [], "returned": 0, "total_visible": total_visible, "filters": filters}, meta
        return {"items": items, "returned": len(items), "total": total_visible, "filters": filters}, meta

    # scan mode: filters the backend ignores, so we walk pages and filter locally

    matches: List[Dict[str, Any]] = []
    seen_scan: set = set()
    duplicates = 0
    scanned = 0
    exhausted = True
    page_no = 1
    max_pages = int(args.max_pages)
    total_visible: Optional[int] = None
    total_pages: Optional[int] = None
    while page_no <= max_pages:
        page = client.video_list_page(
            page_no=page_no,
            page_size=page_size,
            enterprise_id=filter_id,
            account=args.account,
        )
        rows = [r for r in (page.get("list") or []) if isinstance(r, dict)]
        total_visible = page.get("total") if page.get("total") is not None else total_visible
        total_pages = int(page.get("pages") or 0) or total_pages
        meta["total_visible"] = total_visible
        for row in rows:
            scanned += 1
            if platform and platform_from_link(row.get("shareLink")) != platform:
                continue
            if country and str(row.get("country") or "").strip().upper() != country:
                continue
            key = _video_key(row)
            if key in seen_scan:
                duplicates += 1
                continue
            seen_scan.add(key)
            matches.append(row)
        if len(rows) < page_size:
            break
        # Without --sort we can stop as soon as we have enough rows; with --sort we
        # must keep scanning, otherwise the "top" would only be the top of the first pages.
        if not sort_field and len(matches) >= limit:
            exhausted = False
            break
        page_no += 1
    else:
        exhausted = False

    if sort_field:
        matches.sort(key=lambda r: (r.get(sort_field) or 0), reverse=True)

    selected = matches[:limit]
    items = selected if args.raw else [trim_video(r) for r in selected]
    meta.update(
        {
            "scanned_rows": scanned,
            "matched_rows": len(matches),
            "exhaustive": exhausted,
            "partial": (not exhausted) or len(matches) > limit,
            "counts": {
                "total_visible": total_visible,
                "total_pages": total_pages,
                "matched": len(matches),
                "returned": len(items),
            },
            "scan": {
                "pages": page_no if exhausted else max_pages,
                "page_size": page_size,
                "max_pages": max_pages,
                "complete": exhausted,
                "total_visible": total_visible,
                "matched": len(matches),
                "returned": len(items),
                "remaining_matched": max(0, len(matches) - len(items)),
            },
            "pagination": {
                "mode": "full_scan",
                "page_size": page_size,
                "pages_fetched": page_no if exhausted else max_pages,
                "complete": exhausted,
                "dedup": {"by": "workId", "duplicates_removed": duplicates},
            },
        }
    )
    if platform:
        meta["platform_source"] = "derived_from_shareLink"
    if country:
        meta["country_filter"] = country
    if sort_field:
        meta["sorted_by"] = f"{sort_field} desc"
    return {
        "items": items,
        "returned": len(items),
        "total": total_visible,
        "total_matched": len(matches),
        "filters": filters,
    }, meta


def cmd_lead_list(args: Any, base_url: str) -> Dict[str, Any]:
    session = require_auth(resolve_session(base_url, allow_profile=False))
    _reject_cross_tenant(session)
    client = session.client()
    limit = _limit_of(args, 20)
    page_size = _page_size_of(args)
    no_paginate = _no_paginate(args)
    start_page = max(1, int(args.page or 1))
    fields = ("id", "partnerId", "contactName", "companyName", "email", "phone", "dialingCode", "country",
              "requirementDesc", "source", "status", "createdAt")

    rows: List[Dict[str, Any]] = []
    seen: set = set()
    duplicates = 0
    page_no = start_page - 1  # backend lead paging is 0-based
    pages_fetched = 0
    exhausted = False
    out_of_range = False
    total: Optional[int] = None
    while True:
        data = client.lead_page(page_no=page_no, page_size=page_size, source=args.source)
        pages_fetched += 1
        if data.get("total") is not None:
            total = data.get("total")
        batch = [r for r in (data.get("pageResult") or data.get("list") or []) if isinstance(r, dict)]
        if not batch:
            exhausted = True
            if page_no > 0 and not (data.get("total") or 0):
                # The backend reports total=0 for out-of-range pages — that is NOT "no leads".
                probe = client.lead_page(page_no=0, page_size=1, source=args.source)
                total = probe.get("total")
                out_of_range = True
            break
        for row in batch:
            key = str(row.get("id"))
            if key in seen:
                duplicates += 1
                continue
            seen.add(key)
            rows.append(row)
        if len(batch) < page_size:
            exhausted = True
            break
        if len(rows) >= limit or no_paginate:
            break
        page_no += 1

    want_partners = {p.strip() for p in str(getattr(args, "partner", "") or "").split(",") if p.strip()}
    if want_partners:
        rows = [r for r in rows if str(r.get("partnerId")) in want_partners]
    selected = rows[:limit]
    items = [{k: r.get(k) for k in fields if k in r} for r in selected]
    next_page = None if (exhausted or out_of_range or no_paginate) else page_no + 2
    pagination = _pagination_meta(
        start_page, page_size, pages_fetched, next_page, exhausted,
        total, None, len(items), duplicates, "single_page" if no_paginate else "auto",
    )
    meta: Dict[str, Any] = {
        "total": total,
        "page": start_page,
        "page_size": page_size,
        "next_page": next_page,
        "returned": len(items),
        "counts": {"total": total, "returned": len(items), "remaining": pagination.get("remaining")},
        "pagination": pagination,
        "partial": bool(next_page is not None),
        **_identity_meta(session),
    }
    if out_of_range:
        meta.update({
            "out_of_range": True,
            "total_actual": total,
            "note": "请求页超出范围（后端对越界页返回 total=0，不代表没有线索）；已回查第 1 页得到真实总数。",
        })
    meta["field_notes"] = {
        "status": "后端代码值（接口未提供枚举对照），不要直接当文字状态用。",
        "source": "后端代码值（接口未提供枚举对照）。",
    }
    if args.source:
        meta["source_filter"] = args.source
    if want_partners:
        meta["partner_filter"] = sorted(want_partners)
    return {"items": items, "total": total, "returned": len(items),
            "filters": {"source": args.source, "partner": sorted(want_partners) or None},
            "aggregation": "detail_rows",
            "note": (
                "口径：线索明细行（/api/business/selectPage）。`partnerId` = 该线索所属企业（后端原始行即有，"
                "CLI 现对外暴露），--partner 为客户端过滤。注意：该接口目前不校验凭证、也不按租户收敛，"
                "对客必须用客户企业自己的租户凭证调用。"
            )}, meta


def cmd_trend(args: Any, base_url: str) -> Dict[str, Any]:
    import datetime
    session = require_auth(resolve_session(base_url, allow_profile=False))
    _reject_cross_tenant(session)
    client = session.client()
    today = datetime.date.today()

    def _parse(value: Optional[str], default: "datetime.date") -> "datetime.date":
        if not value:
            return default
        try:
            return datetime.date.fromisoformat(value.strip())
        except ValueError:
            raise CliError(
                INVALID_ARG,
                f"日期格式无效: {value}",
                details={"expected": "YYYY-MM-DD"},
                hint="例：--start 2026-09-01 --end 2026-09-07",
            )

    start_d = _parse(args.start, today - datetime.timedelta(days=6))
    end_d = _parse(args.end, today)
    if start_d > end_d:
        raise CliError(INVALID_ARG, "起始日期不能晚于结束日期",
                       details={"start": start_d.isoformat(), "end": end_d.isoformat()})
    start, end = start_d.isoformat(), end_d.isoformat()
    data = client.search_info(start, end, args.account or "")
    available: Dict[str, bool] = {}
    for key, points in (data or {}).items():
        if isinstance(points, list):
            available[key] = any(isinstance(p, dict) and p.get("count") is not None for p in points)
        else:
            available[key] = bool(points)
    meta = {
        "range": {"start": start, "end": end},
        "metrics_available": available,
        "null_meaning": "曲线为空或点值为 null 表示后端本次未返回该指标（链路缺失），不代表 0，不要当 0 用。",
        "window_note": "时间窗由客户指定（自然周/自然月/滚动区间都可以，跟客户确认后再取数）；未指定时这里用的是默认近 7 天。",
        **_identity_meta(session),
    }
    return {"range": {"start": start, "end": end}, "charts": data, "metrics_available": available}, meta


def cmd_hot_video_list(args: Any, base_url: str) -> Dict[str, Any]:
    session = require_auth(resolve_session(base_url, allow_profile=False))
    _reject_cross_tenant(session)
    client = session.client()
    limit = _limit_of(args, 20)
    page_size = _page_size_of(args)
    no_paginate = _no_paginate(args)
    scope = args.scope or "client"
    start_page = max(1, int(args.page or 1))
    fields = ("id", "videoId", "videoTitle", "authorName", "fansCount", "likeCount", "viewCount",
              "commentCount", "shareCount", "level1", "level2", "level3")

    rows: List[Dict[str, Any]] = []
    seen: set = set()
    duplicates = 0
    page_no = start_page - 1
    pages_fetched = 0
    exhausted = False
    out_of_range = False
    total: Optional[int] = None
    while True:
        data = client.hot_video_page(scope, page_no=page_no, page_size=page_size)
        pages_fetched += 1
        if data.get("total") is not None:
            total = data.get("total")
        batch = [r for r in (data.get("pageResult") or data.get("list") or []) if isinstance(r, dict)]
        if not batch:
            exhausted = True
            if page_no > 0 and not (data.get("total") or 0):
                probe = client.hot_video_page(scope, page_no=0, page_size=1)
                total = probe.get("total")
                out_of_range = True
            break
        for row in batch:
            key = str(row.get("id") or row.get("videoId"))
            if key in seen:
                duplicates += 1
                continue
            seen.add(key)
            rows.append(row)
        if len(batch) < page_size:
            exhausted = True
            break
        if len(rows) >= limit or no_paginate:
            break
        page_no += 1

    selected = rows[:limit]
    items = [{k: r.get(k) for k in fields if k in r} for r in selected]
    next_page = None if (exhausted or out_of_range or no_paginate) else page_no + 2
    pagination = _pagination_meta(
        start_page, page_size, pages_fetched, next_page, exhausted,
        total, None, len(items), duplicates, "single_page" if no_paginate else "auto",
    )
    meta: Dict[str, Any] = {
        "total": total,
        "page": start_page,
        "page_size": page_size,
        "next_page": next_page,
        "scope": scope,
        "returned": len(items),
        "counts": {"total": total, "returned": len(items), "remaining": pagination.get("remaining")},
        "pagination": pagination,
        "partial": bool(next_page is not None),
        **_identity_meta(session),
    }
    if out_of_range:
        meta.update({
            "out_of_range": True,
            "total_actual": total,
            "note": "请求页超出范围（后端对越界页返回 total=0，不代表没有数据）；已回查第 1 页得到真实总数。",
        })
    return {"items": items, "total": total, "returned": len(items), "scope": scope}, meta


# --------------------------------------------------------------------------
# selfcheck
# --------------------------------------------------------------------------

STEP_ORDER = (
    "install",
    "config",
    "auth",
    "discovery",
    "readonly_query",
    "tenant_isolation",
)


def cmd_selfcheck(args: Any, base_url: str) -> Dict[str, Any]:
    steps: List[Dict[str, Any]] = []
    started = datetime.now(timezone.utc)

    def add(name: str, status: str, detail: Any, note: Optional[str] = None) -> None:
        entry: Dict[str, Any] = {"step": name, "status": status, "detail": detail}
        if note:
            entry["note"] = note
        steps.append(entry)

    # 1. install -----------------------------------------------------------
    try:
        from importlib.metadata import version

        pkg_version = version("xingqing-cli")
        executable = os.path.basename(sys.argv[0]) or "python -m xingqing_cli"
        add("install", "pass", {"package": "xingqing-cli", "version": pkg_version, "entry": executable})
    except Exception as exc:  # noqa: BLE001 - surfaced as a failed step
        add("install", "fail", {"error": str(exc)}, "未以可安装包方式运行；请执行 pipx install / pip install。")

    # 2. config ------------------------------------------------------------
    env_present = credentials.env_credentials() is not None
    cfg = {
        "base_url": base_url,
        "credential_source": "env" if env_present else ("profile" if credentials.cached_token() else "none"),
        "credentials_path": str(credentials.credentials_path()),
        "credentials_mode": None,
    }
    try:
        path = credentials.credentials_path()
        if path.exists():
            cfg["credentials_mode"] = oct(path.stat().st_mode & 0o777)
    except OSError:
        pass
    if cfg["credential_source"] == "none":
        add("config", "fail", cfg, "缺少凭证：login 或设置 XINGQING_USERNAME/XINGQING_PASSWORD。")
    elif cfg["credentials_mode"] not in (None, "0o600"):
        add("config", "warn", cfg, "凭证文件权限不是 600，建议修复。")
    else:
        add("config", "pass", cfg)

    session = resolve_session(base_url)

    # 3. auth --------------------------------------------------------------
    identity: Dict[str, Any] = {}
    if not session.token:
        add("auth", "fail", {"credential_source": session.source}, "未登录。")
    else:
        try:
            info = session.client().get_current_user()
            user = info.get("userInfo") or {}
            identity = {
                "account": user.get("account"),
                "enterprise": user.get("nickName"),
                "tenant_id": user.get("id"),
                "roles": list(info.get("roles") or []),
            }
            session.tenant_id = user.get("id")
            session.nick_name = user.get("nickName")
            session.roles = list(info.get("roles") or [])
            add("auth", "pass", {**identity, "role_scope": "cross_tenant" if session.is_admin else "tenant"})
        except CliError as exc:
            add("auth", "fail", exc.to_dict(), exc.hint)

    # 4. discovery ---------------------------------------------------------
    try:
        cmds = registry.commands_payload()
        schema = registry.schema_payload()
        missing = [c["name"] for c in cmds if not c.get("summary")]
        add(
            "discovery",
            "fail" if missing else "pass",
            {"commands": len(cmds), "schema_keys": len(schema.get("commands", {})), "missing_summary": missing},
        )
    except Exception as exc:  # noqa: BLE001
        add("discovery", "fail", {"error": str(exc)})

    # 5. read-only query ---------------------------------------------------
    if session.token:
        try:
            client = session.client()
            accounts = client.account_list()
            counts = client.video_count_info()
            page = client.video_list_page(page_no=1, page_size=5)
            rows = [r for r in (page.get("list") or []) if isinstance(r, dict)]
            ok = isinstance(accounts, list) and isinstance(counts, dict)
            add(
                "readonly_query",
                "pass" if ok else "fail",
                {
                    "accounts_visible": len(accounts),
                    "videos_visible": page.get("total"),
                    "allWorkCount": counts.get("allWorkCount"),
                    "rows_sample": len(rows),
                    "sample_enterprise_ids": sorted({r.get("enterpriseId") for r in rows}),
                },
                None if rows else "当前租户暂无已发布视频（查询本身成功）。",
            )
            readonly_rows = rows
        except CliError as exc:
            readonly_rows = []
            add("readonly_query", "fail", exc.to_dict(), exc.hint)
    else:
        readonly_rows = []
        add("readonly_query", "skip", {"reason": "not_authenticated"})

    # 6. tenant isolation ---------------------------------------------------
    if not session.token:
        add("tenant_isolation", "skip", {"reason": "not_authenticated"})
    elif session.is_admin:
        add(
            "tenant_isolation",
            "skip",
            {
                "role_scope": "cross_tenant",
                "roles": session.roles,
                "reason": "manager/operator 账号按设计可跨租户读取，无法用自身会话证明隔离。",
            },
            "请用 client 角色凭证（XINGQING_USERNAME/PASSWORD）重跑 selfcheck 以验证隔离。",
        )
    else:
        probes = [int(x) for x in str(args.isolation_probe_ids).split(",") if x.strip().isdigit()]
        try:
            client = session.client()
            own = client.video_list_page(page_no=1, page_size=50)
            own_rows = [r for r in (own.get("list") or []) if isinstance(r, dict)]
            own_ids = {r.get("enterpriseId") for r in own_rows}
            own_accounts = {r.get("account") for r in own_rows}
            violations: List[Dict[str, Any]] = []
            for probe_id in probes:
                got = client.video_list_page(page_no=1, page_size=50, enterprise_id=probe_id)
                got_rows = [r for r in (got.get("list") or []) if isinstance(r, dict)]
                foreign = [r for r in got_rows if r.get("enterpriseId") not in own_ids]
                if foreign:
                    violations.append({"probe_enterprise_id": probe_id, "foreign_rows": len(foreign)})
            leaked_params = {r.get("account") for r in own_rows} - own_accounts
            status = "fail" if violations else "pass"
            add(
                "tenant_isolation",
                status,
                {
                    "own_tenant_id": session.tenant_id,
                    "own_enterprise_ids": sorted(x for x in own_ids if x is not None),
                    "cross_tenant_probes": probes,
                    "violations": violations,
                    "account_param_leak": sorted(leaked_params),
                },
                None
                if not violations
                else "客户端传入的 enterpriseId 影响了返回结果 —— 服务端租户隔离存在缺口。",
            )
        except CliError as exc:
            add("tenant_isolation", "fail", exc.to_dict(), exc.hint)

    failed = [s["step"] for s in steps if s["status"] == "fail"]
    warned = [s["step"] for s in steps if s["status"] == "warn"]
    skipped = [s["step"] for s in steps if s["status"] == "skip"]
    result = {
        "overall": "fail" if failed else ("pass_with_skips" if skipped else "pass"),
        "failed": failed,
        "warned": warned,
        "skipped": skipped,
        "identity": identity,
        "started_at": started.isoformat(),
    }
    return {"result": result, "steps": steps}, {"selfcheck": True}


COMMAND_TABLE = {
    "status": cmd_status,
    "login": cmd_login,
    "logout": cmd_logout,
    "commands": cmd_commands,
    "schema": cmd_schema,
    "account list": cmd_account_list,
    "account stats": cmd_account_stats,
    "video count": cmd_video_count,
    "video list": cmd_video_list,
    "lead list": cmd_lead_list,
    "trend": cmd_trend,
    "hot-video list": cmd_hot_video_list,
    "selfcheck": cmd_selfcheck,
}


def dispatch(command: str, args: Any, base_url: str) -> Tuple[Any, Dict[str, Any]]:
    handler = COMMAND_TABLE.get(command)
    if handler is None:
        raise CliError(INVALID_ARG, f"未知命令: {command}")
    outcome = handler(args, base_url)
    if isinstance(outcome, tuple):
        return outcome
    return outcome, {}
