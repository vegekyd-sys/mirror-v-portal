"""Stable machine-readable error codes.

The contract: every failure exits non-zero and prints a JSON envelope whose
``error.code`` is one of the codes below. Raw tracebacks never reach stdout.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

# --- stable error codes -------------------------------------------------
CONFIG_ERROR = "CONFIG_ERROR"
AUTH_REQUIRED = "AUTH_REQUIRED"
AUTH_FAILED = "AUTH_FAILED"
AUTH_EXPIRED = "AUTH_EXPIRED"
NETWORK_ERROR = "NETWORK_ERROR"
API_ERROR = "API_ERROR"
NOT_FOUND = "NOT_FOUND"
INVALID_ARG = "INVALID_ARG"
UNSUPPORTED = "UNSUPPORTED"
INTERNAL_ERROR = "INTERNAL_ERROR"

ALL_CODES = (
    CONFIG_ERROR,
    AUTH_REQUIRED,
    AUTH_FAILED,
    AUTH_EXPIRED,
    NETWORK_ERROR,
    API_ERROR,
    NOT_FOUND,
    INVALID_ARG,
    UNSUPPORTED,
    INTERNAL_ERROR,
)

# Backend response codes observed on the live 星擎 API.
BACKEND_CODE_MAP = {
    "401": (AUTH_EXPIRED, "登录凭证无效，请重新登录"),
    "4001": (AUTH_FAILED, "用户不存在"),
    "4002": (AUTH_FAILED, "密码错误"),
}

EXIT_OK = 0
EXIT_ERROR = 1
EXIT_USAGE = 2


class CliError(Exception):
    """An error that maps onto a stable CLI error code."""

    def __init__(
        self,
        code: str,
        message: str,
        details: Optional[Dict[str, Any]] = None,
        exit_code: int = EXIT_ERROR,
        hint: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.code = code if code in ALL_CODES else INTERNAL_ERROR
        self.message = message
        self.details = details
        self.exit_code = exit_code
        self.hint = hint

    def to_dict(self) -> Dict[str, Any]:
        err: Dict[str, Any] = {"code": self.code, "message": self.message}
        if self.hint:
            err["hint"] = self.hint
        if self.details:
            err["details"] = self.details
        return err
